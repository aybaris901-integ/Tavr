package kz.tavr

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import dagger.hilt.android.HiltAndroidApp
import kz.tavr.service.Notifier
import org.maplibre.android.MapLibre
import javax.inject.Inject

@HiltAndroidApp
class TavrApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var notifier: Notifier

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder().setWorkerFactory(workerFactory).build()

    override fun onCreate() {
        super.onCreate()
        MapLibre.getInstance(this) // нужен и карте, и офлайн-загрузке тайлов
        notifier.createChannels()
    }
}
