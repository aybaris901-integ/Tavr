package kz.tavr.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DynamicFeed
import androidx.compose.material.icons.outlined.FlightTakeoff
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import dagger.hilt.android.AndroidEntryPoint
import kz.tavr.R
import kz.tavr.domain.AppLanguage
import kz.tavr.service.Notifier
import kz.tavr.ui.feed.FeedScreen
import kz.tavr.ui.flight.FlightScreen
import kz.tavr.ui.map.MapScreen
import kz.tavr.ui.settings.SettingsScreen
import kz.tavr.ui.theme.TavrTheme

private enum class Tab(val route: String, val label: Int, val icon: ImageVector) {
    FLIGHT("flight", R.string.nav_flight, Icons.Outlined.FlightTakeoff),
    MAP("map", R.string.nav_map, Icons.Outlined.Map),
    FEED("feed", R.string.nav_feed, Icons.Outlined.DynamicFeed),
    SETTINGS("settings", R.string.nav_settings, Icons.Outlined.Settings),
}

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    /** Открыть «Таспа» по нажатию на уведомление. */
    private val openFeed = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Язык по умолчанию — казахский, независимо от языка системы.
        if (AppCompatDelegate.getApplicationLocales().isEmpty) AppLanguage.apply(AppLanguage.KK_CYRL)
        enableEdgeToEdge()
        openFeed.value = intent.getBooleanExtra(Notifier.EXTRA_OPEN_FEED, false)
        setContent {
            TavrTheme {
                TavrRoot(openFeed.value) { openFeed.value = false }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(Notifier.EXTRA_OPEN_FEED, false)) openFeed.value = true
    }
}

@Composable
private fun TavrRoot(openFeed: Boolean, onFeedOpened: () -> Unit) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    fun go(tab: Tab) = nav.navigate(tab.route) {
        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }

    LaunchedEffect(openFeed) {
        if (openFeed) {
            go(Tab.FEED)
            onFeedOpened()
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                Tab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = currentRoute == tab.route,
                        onClick = { go(tab) },
                        icon = { Icon(tab.icon, contentDescription = null) },
                        label = { Text(stringResource(tab.label)) },
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(bottom = padding.calculateBottomPadding())) {
            NavHost(nav, startDestination = Tab.FLIGHT.route) {
                composable(Tab.FLIGHT.route) { FlightScreen() }
                composable(Tab.MAP.route) { MapScreen() }
                composable(Tab.FEED.route) { FeedScreen() }
                composable(Tab.SETTINGS.route) { SettingsScreen() }
            }
        }
    }
}
