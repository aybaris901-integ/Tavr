package kz.tavr.domain

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import kz.tavr.R
import kz.tavr.data.local.PoiEntity
import kz.tavr.geo.Transliterator

/** Языки интерфейса Tavr. */
enum class AppLanguage(val tag: String, val selfName: String) {
    KK_CYRL("kk", "Қазақша"),
    KK_LATN("kk-Latn", "Qazaqşa (latyn)"),
    RU("ru", "Русский"),
    EN("en", "English");

    companion object {
        fun current(): AppLanguage {
            val tag = AppCompatDelegate.getApplicationLocales().toLanguageTags()
            return entries.firstOrNull { it.tag.equals(tag, ignoreCase = true) } ?: KK_CYRL
        }

        fun apply(lang: AppLanguage) {
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(lang.tag))
        }
    }
}

object Lang {
    /**
     * Контекст с выбранным в приложении языком — для сервиса и WorkManager,
     * которые на Android < 13 не видят языка, выбранного через AppCompat.
     */
    fun localized(context: Context): Context {
        val locales = AppCompatDelegate.getApplicationLocales()
        if (locales.isEmpty) return context
        val config = Configuration(context.resources.configuration)
        config.setLocales(LocaleList.forLanguageTags(locales.toLanguageTags()))
        return context.createConfigurationContext(config)
    }

    private fun isLatin(ctx: Context): Boolean {
        val l = ctx.resources.configuration.locales[0]
        return l.language == "kk" && l.script == "Latn"
    }

    private fun language(ctx: Context): String = ctx.resources.configuration.locales[0].language

    /** Название POI для текущего языка интерфейса. */
    fun poiName(ctx: Context, poi: PoiEntity): String = when (language(ctx)) {
        "ru" -> poi.nameRu ?: poi.name
        "en" -> poi.nameEn ?: poi.name
        else -> if (isLatin(ctx)) Transliterator.kkCyrillicToLatin(poi.name) else poi.name
    }

    /** Текст описания и пометка о его происхождении (или null). */
    fun poiDescription(ctx: Context, poi: PoiEntity): Pair<String, Int?> {
        val lang = language(ctx)
        if (lang != "kk" && poi.sourceText != null && poi.sourceLang == lang) return poi.sourceText to null
        val kk = poi.description
        if (kk != null) {
            val text = if (isLatin(ctx)) Transliterator.kkCyrillicToLatin(kk) else kk
            @StringRes val note = if (poi.descSource == DescSource.LLM) R.string.desc_translated else null
            return text to note
        }
        if (poi.sourceText != null) return poi.sourceText to R.string.desc_original_lang
        return ctx.getString(R.string.desc_missing) to null
    }
}
