package kz.tavr.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Цвета флага Казахстана
val Sky = Color(0xFF00AFCA)
val SkyDeep = Color(0xFF007C90)
val SkyMist = Color(0xFFE3F6FA)
val Gold = Color(0xFFFEC50C)
val GoldDeep = Color(0xFF8A6A00)
val Night = Color(0xFF0B1E2B)
val NightSurface = Color(0xFF132C3C)

private val Light = lightColorScheme(
    primary = SkyDeep,
    onPrimary = Color.White,
    primaryContainer = SkyMist,
    onPrimaryContainer = Color(0xFF00363F),
    secondary = Gold,
    onSecondary = Color(0xFF241A00),
    secondaryContainer = Color(0xFFFFF0C2),
    onSecondaryContainer = Color(0xFF3B2E00),
    tertiary = GoldDeep,
    background = Color.White,
    surface = Color.White,
    surfaceVariant = Color(0xFFF1F6F8),
    onSurfaceVariant = Color(0xFF41545B),
    outline = Color(0xFFB7C6CC),
)

private val Dark = darkColorScheme(
    primary = Sky,
    onPrimary = Color(0xFF00363F),
    primaryContainer = Color(0xFF004E5B),
    onPrimaryContainer = SkyMist,
    secondary = Gold,
    onSecondary = Color(0xFF241A00),
    secondaryContainer = Color(0xFF574300),
    onSecondaryContainer = Color(0xFFFFE08A),
    tertiary = Gold,
    background = Night,
    surface = Night,
    surfaceVariant = NightSurface,
    onSurfaceVariant = Color(0xFFB9CCD3),
    outline = Color(0xFF3E5866),
)

private val TavrType = Typography().let { t ->
    t.copy(
        headlineMedium = t.headlineMedium.copy(fontWeight = FontWeight.SemiBold, letterSpacing = (-0.5).sp),
        titleLarge = t.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        titleMedium = t.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        labelSmall = TextStyle(fontSize = 11.sp, letterSpacing = 0.4.sp),
    )
}

@Composable
fun TavrTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, typography = TavrType, content = content)
}
