package kz.tavr.work

import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import android.util.Log
import androidx.annotation.StringRes
import androidx.hilt.work.HiltWorker
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kz.tavr.R
import kz.tavr.data.cache.OfflineMapManager
import kz.tavr.data.local.FlightDao
import kz.tavr.data.repository.PoiRepository
import kz.tavr.data.repository.SpaceWeatherRepository
import kz.tavr.data.settings.SettingsRepository
import kz.tavr.domain.FlightStatus
import kz.tavr.service.Notifier
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.TimeUnit

/** Шаги подготовки — в том порядке, в каком их видит пассажир. */
enum class PrepStep(@StringRes val label: Int) {
    ROUTE(R.string.step_route),
    POI(R.string.step_poi),
    TEXT(R.string.step_text),
    PHOTO(R.string.step_photo),
    KP(R.string.step_kp),
    TILES(R.string.step_tiles),
}

/**
 * «Ұшуға дайындалу»: пока есть интернет, собирает всё, что понадобится в небе.
 * Маршрут (шаг ROUTE) уже найден на экране «Рейс» — здесь остальные шаги.
 */
@HiltWorker
class PrepareFlightWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val flights: FlightDao,
    private val pois: PoiRepository,
    private val spaceWeather: SpaceWeatherRepository,
    private val offlineMap: OfflineMapManager,
    private val settings: SettingsRepository,
    private val notifier: Notifier,
) : CoroutineWorker(context, params) {

    companion object {
        const val KEY_FLIGHT_ID = "flightId"
        const val KEY_STEP = "step"
        const val KEY_PERCENT = "percent"
        const val KEY_TILES_SKIPPED = "tilesSkipped"
        const val KEY_ERROR = "error"
        private const val TAG = "PrepareFlightWorker"

        fun uniqueName(flightId: Long) = "prepare_$flightId"

        fun enqueue(context: Context, flightId: Long) {
            val request = OneTimeWorkRequestBuilder<PrepareFlightWorker>()
                .setInputData(workDataOf(KEY_FLIGHT_ID to flightId))
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build()
            WorkManager.getInstance(context)
                .enqueueUniqueWork(uniqueName(flightId), ExistingWorkPolicy.REPLACE, request)
        }
    }

    private var tilesSkipped = false

    override suspend fun doWork(): Result {
        val flightId = inputData.getLong(KEY_FLIGHT_ID, -1)
        val flight = flights.get(flightId) ?: return Result.failure()
        runCatching { setForeground(getForegroundInfo()) } // долгая работа не должна убиваться системой

        return try {
            val alreadyReady = flight.status == FlightStatus.READY
            if (!alreadyReady) flights.setStatus(flightId, FlightStatus.PREPARING)

            // Объекты уже найдены (повторный запуск) — не ищем заново, только дозагружаем недостающее.
            val existing = pois.count(flightId)
            if (existing == 0) {
                step(PrepStep.POI) { p -> pois.collectAlongRoute(flight, p) }
                    .also { flights.setPoiCount(flightId, it) }
            } else {
                flights.setPoiCount(flightId, existing)
            }
            step(PrepStep.TEXT) { p -> pois.fillDescriptions(flightId, p) }
            step(PrepStep.PHOTO) { p -> pois.downloadPhotos(flightId, p) }
            step(PrepStep.KP) { _ -> runCatching { spaceWeather.refresh() } } // не критично

            // Главное готово: с этого момента можно включать режим полёта, даже если карта не скачается.
            flights.setStatus(flightId, FlightStatus.READY)

            // Офлайн-карта — необязательный бонус. Без ключа MapTiler не качаем вовсе;
            // при повторном запуске (прошлая попытка упала на карте) тоже пропускаем.
            val key = settings.current().mapTilerKey
            tilesSkipped = key.isBlank() || (alreadyReady && runAttemptCount > 0)
            if (!tilesSkipped) {
                step(PrepStep.TILES) { p ->
                    val ok = runCatching {
                        withTimeoutOrNull(15 * 60_000L) {
                            offlineMap.downloadCorridor(flight, key) { percent -> notifier.updatePrepare(PrepStep.TILES, percent) }
                        } ?: false
                    }.onFailure { Log.w(TAG, "offline tiles failed", it) }.getOrDefault(false)
                    p(100)
                    flights.setTilesReady(flightId, ok)
                }
            } else {
                report(PrepStep.TILES, 100)
            }

            notifier.cancelPrepare()
            Result.success(workDataOf(KEY_TILES_SKIPPED to tilesSkipped))
        } catch (e: Exception) {
            Log.e(TAG, "prepare failed", e)
            if (flights.get(flightId)?.status == FlightStatus.READY) {
                notifier.cancelPrepare()
                Result.success(workDataOf(KEY_TILES_SKIPPED to true))
            } else if (runAttemptCount < 2) {
                Result.retry()
            } else {
                flights.setStatus(flightId, FlightStatus.FAILED, e.message ?: e.javaClass.simpleName)
                notifier.cancelPrepare()
                Result.failure(workDataOf(KEY_ERROR to (e.message ?: e.javaClass.simpleName)))
            }
        }
    }

    private suspend fun <T> step(step: PrepStep, block: suspend (suspend (Int) -> Unit) -> T): T {
        report(step, 0)
        val result = block { percent -> report(step, percent) }
        report(step, 100)
        return result
    }

    private suspend fun report(step: PrepStep, percent: Int) {
        setProgress(workDataOf(KEY_STEP to step.ordinal, KEY_PERCENT to percent, KEY_TILES_SKIPPED to tilesSkipped))
        notifier.updatePrepare(step, percent)
    }

    override suspend fun getForegroundInfo(): ForegroundInfo {
        val notification = notifier.prepareNotification(PrepStep.POI, 0)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(Notifier.ID_PREPARE, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(Notifier.ID_PREPARE, notification)
        }
    }
}
