package kz.tavr.service

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.HandlerThread
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kz.tavr.R
import kz.tavr.data.local.FlightDao
import kz.tavr.data.local.FlightEntity
import kz.tavr.data.local.PoiDao
import kz.tavr.data.local.TrackDao
import kz.tavr.data.local.TrackPointEntity
import kz.tavr.data.repository.SpaceWeatherRepository
import kz.tavr.domain.FlightStatus
import kz.tavr.domain.Lang
import kz.tavr.geo.AlertPolicy
import kz.tavr.geo.ClockDirection
import kz.tavr.geo.CourseEstimator
import kz.tavr.geo.Fix
import kz.tavr.geo.GeoMath
import kz.tavr.geo.LatLon
import kz.tavr.geo.Motion
import kz.tavr.geo.PoiTarget
import javax.inject.Inject

/**
 * «Ұшу режимі»: полностью офлайн. GPS-приёмник ничего не передаёт, поэтому
 * работает и в авиарежиме. Каждые 30 с: точка → курс → кому сказать «терезеге қара!».
 */
@AndroidEntryPoint
class FlightModeService : LifecycleService() {

    companion object {
        private const val ACTION_STOP = "kz.tavr.STOP"
        private const val EXTRA_FLIGHT = "flightId"
        private const val INTERVAL_MS = 30_000L
        /** Без GPS дольше этого — переходим на оценку позиции. */
        private const val GPS_STALE_MS = 3 * 60_000L
        /** Счисление от последней GPS-точки разумно не дольше получаса. */
        private const val DEAD_RECKONING_MAX_MS = 30 * 60_000L
        private const val CRUISE_KMH = 830.0
        private const val MAX_ALERTS_PER_TICK = 2
        private const val AURORA_COOLDOWN_MS = 60 * 60_000L

        fun start(context: Context, flightId: Long) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, FlightModeService::class.java).putExtra(EXTRA_FLIGHT, flightId),
            )
        }

        fun stop(context: Context) {
            context.startService(Intent(context, FlightModeService::class.java).setAction(ACTION_STOP))
        }
    }

    @Inject lateinit var flights: FlightDao
    @Inject lateinit var pois: PoiDao
    @Inject lateinit var track: TrackDao
    @Inject lateinit var spaceWeather: SpaceWeatherRepository
    @Inject lateinit var notifier: Notifier
    @Inject lateinit var session: FlightSession

    private val policy = AlertPolicy()
    private val mutex = Mutex()
    private var flight: FlightEntity? = null
    private var lastAuroraAt = 0L
    private var gpsThread: HandlerThread? = null
    private var started = false
    private val locationManager by lazy { getSystemService(LocationManager::class.java) }

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            val fix = Fix(
                timeMillis = location.time,
                lat = location.latitude,
                lon = location.longitude,
                altitudeM = if (location.hasAltitude()) location.altitude else null,
                speedKmh = if (location.hasSpeed()) location.speed * 3.6 else null,
                bearingDeg = if (location.hasBearing()) location.bearing.toDouble() else null,
            )
            lifecycleScope.launch { onFix(fix, estimated = false) }
        }

        // На Android < 11 эти методы абстрактные — переопределяем явно.
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
        override fun onProviderEnabled(provider: String) = Unit
        override fun onProviderDisabled(provider: String) = Unit
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        val flightId = intent?.getLongExtra(EXTRA_FLIGHT, -1L) ?: -1L

        ServiceCompat.startForeground(
            this,
            Notifier.ID_SERVICE,
            notifier.flightNotification(Lang.localized(this).getString(R.string.gps_searching)),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0,
        )

        if (started) return START_REDELIVER_INTENT
        started = true
        lifecycleScope.launch {
            val f = (if (flightId > 0) flights.get(flightId) else flights.latest()) ?: run { shutdown(); return@launch }
            flight = f
            flights.setStatus(f.id, FlightStatus.FLYING)
            session.start(f.id)
            startGps()
            ticker()
        }
        return START_REDELIVER_INTENT
    }

    @SuppressLint("MissingPermission") // разрешение проверяется на экране «Рейс» до запуска
    private fun startGps() {
        if (gpsThread != null) return
        val thread = HandlerThread("tavr-gps").also { it.start() }
        gpsThread = thread
        runCatching {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, INTERVAL_MS, 0f, listener, thread.looper,
            )
        }
    }

    /** Раз в 30 с: если GPS молчит — оцениваем позицию, чтобы подсказки не пропали. */
    private suspend fun ticker() {
        while (lifecycleScope.isActive) {
            delay(INTERVAL_MS)
            val f = flight ?: continue
            val last = track.lastGps(f.id)
            val now = System.currentTimeMillis()
            if (last == null || now - last.time > GPS_STALE_MS) {
                estimatePosition(f, last, now)?.let { onFix(it, estimated = true) }
            }
        }
    }

    private suspend fun estimatePosition(f: FlightEntity, last: TrackPointEntity?, now: Long): Fix? {
        // а) счисление от последней GPS-точки
        if (last != null && now - last.time < DEAD_RECKONING_MAX_MS) {
            val recent = track.since(f.id, last.time - CourseEstimator.DEFAULT_WINDOW_MS).filter { !it.estimated }
            val motion = CourseEstimator.estimate(recent.map { it.toFix() })
            if (motion != null) {
                val km = motion.speedKmh * (now - last.time) / 3_600_000.0
                val p = GeoMath.destination(LatLon(last.lat, last.lon), motion.courseDeg, km)
                return Fix(now, p.lat, p.lon, last.altitudeM, motion.speedKmh, motion.courseDeg)
            }
        }
        // б) по расписанию вдоль дуги большого круга
        val dep = f.depTimeUtc ?: return null
        val arr = f.arrTimeUtc ?: return null
        if (now !in dep..arr) return null
        val fraction = (now - dep).toDouble() / (arr - dep)
        val p = GeoMath.interpolate(f.dep, f.arr, fraction)
        val speed = f.distanceKm / ((arr - dep) / 3_600_000.0)
        val course = GeoMath.initialBearing(p, f.arr)
        return Fix(now, p.lat, p.lon, null, speed, course)
    }

    private suspend fun onFix(fix: Fix, estimated: Boolean) = mutex.withLock {
        val f = flight ?: return@withLock
        track.insert(
            TrackPointEntity(
                flightId = f.id, time = fix.timeMillis, lat = fix.lat, lon = fix.lon,
                altitudeM = fix.altitudeM, speedKmh = fix.speedKmh, bearingDeg = fix.bearingDeg,
                estimated = estimated,
            ),
        )

        // Курс — по последним точкам; пока их мало — на аэропорт прилёта с крейсерской скоростью.
        val recent = track.since(f.id, fix.timeMillis - CourseEstimator.DEFAULT_WINDOW_MS)
        val motion = CourseEstimator.estimate(recent.map { it.toFix() })
            ?: Motion(GeoMath.initialBearing(fix.latLon, f.arr), fix.speedKmh?.takeIf { it > 200 } ?: CRUISE_KMH)

        val pending = pois.pending(f.id)
        val night = policy.isNight(fix)

        // POI: за 2–3 минуты до максимального сближения
        val byId = pending.associateBy { it.qid }
        val alerts = policy.poiAlerts(fix, motion, f.seat, pending.map { PoiTarget(it.qid, it.position) })
            .sortedByDescending { byId[it.poiId]?.sitelinks ?: 0 }
            .take(MAX_ALERTS_PER_TICK)
        for (a in alerts) {
            val poi = byId[a.poiId] ?: continue
            notifier.poiAlert(poi, a.sighting)
            pois.markSeen(f.id, poi.qid, fix.timeMillis, a.sighting.side)
        }

        // Северное сияние: ночь, Kp ≥ 4, широта > 55°
        if (fix.timeMillis - lastAuroraAt > AURORA_COOLDOWN_MS) {
            policy.auroraAlert(fix, motion, spaceWeather.kpAt(fix.timeMillis), f.seat)?.let {
                notifier.auroraAlert(it)
                lastAuroraAt = fix.timeMillis
            }
        }

        // Ближайший объект впереди — для строки статуса
        val ctx = Lang.localized(this)
        val alerted = alerts.map { it.poiId }.toSet()
        val next = pending.asSequence()
            .filter { it.qid !in alerted }
            .map { it to ClockDirection.sighting(fix.latLon, motion.courseDeg, motion.speedKmh, it.position) }
            .filter { (_, s) -> s.alongKm > 0 && s.closestKm <= 150 }
            .minByOrNull { (_, s) -> s.alongKm }

        session.update {
            it.copy(
                fix = fix,
                motion = motion,
                estimated = estimated,
                night = night,
                nextPoiName = next?.first?.let { p -> Lang.poiName(ctx, p) },
                nextPoiKm = next?.second?.alongKm?.toInt(),
            )
        }
        val status = when {
            night -> ctx.getString(R.string.night_quiet)
            next != null -> ctx.getString(R.string.next_poi, Lang.poiName(ctx, next.first), next.second.alongKm.toInt())
            estimated -> ctx.getString(R.string.position_estimated)
            else -> ctx.getString(R.string.flight_status, motion.speedKmh.toInt(), (fix.altitudeM ?: 0.0).toInt())
        }
        notifier.updateFlight(status)
    }

    private fun TrackPointEntity.toFix() = Fix(time, lat, lon, altitudeM, speedKmh, bearingDeg)

    private fun shutdown() {
        runCatching { locationManager.removeUpdates(listener) }
        gpsThread?.quitSafely()
        gpsThread = null
        session.stop()
        lifecycleScope.launch {
            // Если сервис уже был убит системой, статус «в полёте» мог остаться в базе — сбрасываем.
            val f = flight ?: flights.latest()?.takeIf { it.status == FlightStatus.FLYING }
            f?.let { flights.setStatus(it.id, FlightStatus.READY) }
            ServiceCompat.stopForeground(this@FlightModeService, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onDestroy() {
        runCatching { locationManager.removeUpdates(listener) }
        gpsThread?.quitSafely()
        session.stop()
        super.onDestroy()
    }
}
