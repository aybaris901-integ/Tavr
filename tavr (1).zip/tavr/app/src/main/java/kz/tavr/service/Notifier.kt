package kz.tavr.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import kz.tavr.R
import kz.tavr.data.local.PoiEntity
import kz.tavr.domain.Lang
import kz.tavr.domain.PoiType
import kz.tavr.geo.AuroraAlert
import kz.tavr.geo.Side
import kz.tavr.geo.Sighting
import kz.tavr.ui.MainActivity
import kz.tavr.work.PrepStep
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.ceil

@Singleton
class Notifier @Inject constructor(
    @ApplicationContext private val app: Context,
) {
    companion object {
        const val CH_ALERTS = "alerts"
        const val CH_SERVICE = "flight_mode"
        const val CH_PREPARE = "prepare"
        const val ID_PREPARE = 1001
        const val ID_SERVICE = 1002
        const val ID_AURORA = 1003
        const val EXTRA_OPEN_FEED = "open_feed"
    }

    /** Строки всегда на выбранном в приложении языке. */
    private val ctx get() = Lang.localized(app)
    private val nm get() = NotificationManagerCompat.from(app)

    fun createChannels() {
        val c = ctx
        val manager = app.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannels(
            listOf(
                NotificationChannel(CH_ALERTS, c.getString(R.string.channel_alerts), NotificationManager.IMPORTANCE_HIGH),
                NotificationChannel(CH_SERVICE, c.getString(R.string.channel_service), NotificationManager.IMPORTANCE_LOW),
                NotificationChannel(CH_PREPARE, c.getString(R.string.channel_prepare), NotificationManager.IMPORTANCE_LOW),
            ),
        )
    }

    private fun openApp(feed: Boolean): PendingIntent = PendingIntent.getActivity(
        app,
        if (feed) 1 else 0,
        Intent(app, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(EXTRA_OPEN_FEED, feed),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun canNotify() =
        ContextCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED || android.os.Build.VERSION.SDK_INT < 33

    @Suppress("MissingPermission")
    private fun post(id: Int, n: Notification) {
        if (canNotify()) nm.notify(id, n)
    }

    // ---------------- подготовка

    fun prepareNotification(step: PrepStep, percent: Int): Notification {
        val c = ctx
        return NotificationCompat.Builder(app, CH_PREPARE)
            .setSmallIcon(R.drawable.ic_stat_tavr)
            .setContentTitle(c.getString(R.string.prepare_running))
            .setContentText(c.getString(step.label))
            .setProgress(100, percent, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(false))
            .build()
    }

    fun updatePrepare(step: PrepStep, percent: Int) = post(ID_PREPARE, prepareNotification(step, percent))

    fun cancelPrepare() = nm.cancel(ID_PREPARE)

    // ---------------- режим полёта

    fun flightNotification(text: String): Notification {
        val c = ctx
        return NotificationCompat.Builder(app, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat_tavr)
            .setContentTitle(c.getString(R.string.flight_mode_running))
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_NAVIGATION)
            .setContentIntent(openApp(false))
            .build()
    }

    fun updateFlight(text: String) = post(ID_SERVICE, flightNotification(text))

    // ---------------- «Бауырым, терезеге қара!»

    fun sideText(side: Side): String = ctx.getString(
        when (side) {
            Side.LEFT -> R.string.side_left
            Side.RIGHT -> R.string.side_right
            Side.BELOW -> R.string.side_below
        },
    )

    fun clockText(hour: Int): String = ctx.resources.getQuantityString(R.plurals.clock_dir, hour, hour)

    /** «{Сторона} — {Название} ({высота} м), сағат {N} бағытында, {M} минуттан кейін» */
    fun poiBody(poi: PoiEntity, s: Sighting): String {
        val c = ctx
        val minutes = ceil(s.minutesToClosest ?: 1.0).toInt().coerceAtLeast(1)
        val elev = if (poi.elevationM != null && poi.type in setOf(PoiType.MOUNTAIN, PoiType.VOLCANO)) {
            c.getString(R.string.elevation_suffix, poi.elevationM)
        } else ""
        return c.getString(
            R.string.notif_body,
            sideText(s.side),
            Lang.poiName(c, poi),
            elev,
            clockText(s.clock),
            c.resources.getQuantityString(R.plurals.minutes_later, minutes, minutes),
        )
    }

    fun poiAlert(poi: PoiEntity, s: Sighting) {
        val c = ctx
        val body = poiBody(poi, s)
        val photo = poi.photoPath?.let { loadBitmap(it) }
        val builder = NotificationCompat.Builder(app, CH_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_tavr)
            .setContentTitle(c.getString(R.string.notif_title))
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_RECOMMENDATION)
            .setAutoCancel(true)
            .setContentIntent(openApp(true))
        if (photo != null) {
            builder.setLargeIcon(photo)
                .setStyle(
                    NotificationCompat.BigPictureStyle()
                        .bigPicture(photo)
                        .bigLargeIcon(null as Bitmap?)
                        .setSummaryText(body),
                )
        } else {
            builder.setStyle(NotificationCompat.BigTextStyle().bigText(body))
        }
        post(poi.qid.hashCode(), builder.build())
    }

    fun auroraAlert(a: AuroraAlert) {
        val c = ctx
        val body = c.getString(
            R.string.aurora_body,
            String.format(java.util.Locale.US, "%.0f", a.kp),
            sideText(a.side),
            clockText(a.clock),
        )
        post(
            ID_AURORA,
            NotificationCompat.Builder(app, CH_ALERTS)
                .setSmallIcon(R.drawable.ic_stat_tavr)
                .setContentTitle(c.getString(R.string.aurora_title))
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(openApp(false))
                .build(),
        )
    }

    /** Пример для экрана настроек. */
    fun testAlert() {
        val c = ctx
        val body = c.getString(
            R.string.notif_body,
            sideText(Side.LEFT),
            c.getString(R.string.test_poi_name),
            c.getString(R.string.elevation_suffix, 6995),
            clockText(10),
            c.resources.getQuantityString(R.plurals.minutes_later, 3, 3),
        )
        post(
            4242,
            NotificationCompat.Builder(app, CH_ALERTS)
                .setSmallIcon(R.drawable.ic_stat_tavr)
                .setContentTitle(c.getString(R.string.notif_title))
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build(),
        )
    }

    private fun loadBitmap(path: String): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1024) sample *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    }.getOrNull()
}
