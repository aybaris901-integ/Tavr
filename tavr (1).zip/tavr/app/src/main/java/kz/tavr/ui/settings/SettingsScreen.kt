package kz.tavr.ui.settings

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kz.tavr.R
import kz.tavr.data.settings.ApiKeys
import kz.tavr.data.settings.SettingsRepository
import kz.tavr.domain.AppLanguage
import kz.tavr.service.Notifier
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val repo: SettingsRepository,
    private val notifier: Notifier,
) : ViewModel() {
    val keys = repo.keys.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun save(keys: ApiKeys, onDone: () -> Unit) = viewModelScope.launch {
        repo.save(keys)
        onDone()
    }

    fun testNotification() = notifier.testAlert()
}

@Composable
fun SettingsScreen(vm: SettingsViewModel = hiltViewModel()) {
    val stored by vm.keys.collectAsStateWithLifecycle()
    var draft by remember { mutableStateOf<ApiKeys?>(null) }
    var saved by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(stored) { if (draft == null && stored != null) draft = stored }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.testNotification()
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(stringResource(R.string.settings_language), style = MaterialTheme.typography.titleLarge)
        val current = AppLanguage.current()
        AppLanguage.entries.forEach { lang ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .selectable(selected = lang == current, role = Role.RadioButton) { AppLanguage.apply(lang) }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = lang == current, onClick = null)
                Spacer(Modifier.width(12.dp))
                Text(lang.selfName)
            }
        }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        Text(stringResource(R.string.settings_keys), style = MaterialTheme.typography.titleLarge)
        Text(stringResource(R.string.keys_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        draft?.let { d ->
            KeyField(R.string.key_openrouter, d.openRouterKey, secret = true) { draft = d.copy(openRouterKey = it); saved = false }
            KeyField(R.string.key_model, d.openRouterModel, secret = false) { draft = d.copy(openRouterModel = it); saved = false }
            KeyField(R.string.key_aerodatabox, d.aeroDataBoxKey, secret = true) { draft = d.copy(aeroDataBoxKey = it); saved = false }
            KeyField(R.string.key_maptiler, d.mapTilerKey, secret = true) { draft = d.copy(mapTilerKey = it); saved = false }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { vm.save(d) { saved = true } }) { Text(stringResource(R.string.btn_save)) }
                if (saved) {
                    Spacer(Modifier.width(12.dp))
                    Text(stringResource(R.string.saved), color = MaterialTheme.colorScheme.primary)
                }
            }
        }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        OutlinedButton(onClick = {
            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            else vm.testNotification()
        }) { Text(stringResource(R.string.btn_test_notification)) }

        Text(stringResource(R.string.slogan), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        Text(stringResource(R.string.settings_about), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun KeyField(label: Int, value: String, secret: Boolean, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(stringResource(label)) },
        singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        modifier = Modifier.fillMaxWidth(),
    )
}
