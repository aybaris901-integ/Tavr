package kz.tavr.data.settings

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "tavr_settings")

data class ApiKeys(
    val openRouterKey: String = "",
    val openRouterModel: String = DEFAULT_MODEL,
    val aeroDataBoxKey: String = "",
    val mapTilerKey: String = "",
) {
    companion object {
        /** Можно заменить на любую модель OpenRouter, хорошо знающую казахский. */
        const val DEFAULT_MODEL = "anthropic/claude-sonnet-4.5"
    }
}

/** Ключи API хранятся только на устройстве (DataStore в приватной папке приложения). */
@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private object K {
        val openRouter = stringPreferencesKey("openrouter_key")
        val model = stringPreferencesKey("openrouter_model")
        val aeroDataBox = stringPreferencesKey("aerodatabox_key")
        val mapTiler = stringPreferencesKey("maptiler_key")
    }

    val keys: Flow<ApiKeys> = context.dataStore.data.map { p ->
        ApiKeys(
            openRouterKey = p[K.openRouter].orEmpty(),
            openRouterModel = p[K.model]?.takeIf { it.isNotBlank() } ?: ApiKeys.DEFAULT_MODEL,
            aeroDataBoxKey = p[K.aeroDataBox].orEmpty(),
            mapTilerKey = p[K.mapTiler].orEmpty(),
        )
    }

    suspend fun current(): ApiKeys = keys.first()

    suspend fun save(keys: ApiKeys) {
        context.dataStore.edit { p ->
            p[K.openRouter] = keys.openRouterKey.trim()
            p[K.model] = keys.openRouterModel.trim()
            p[K.aeroDataBox] = keys.aeroDataBoxKey.trim()
            p[K.mapTiler] = keys.mapTilerKey.trim()
        }
    }
}
