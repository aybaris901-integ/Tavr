package kz.tavr.data.cache

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kz.tavr.data.local.FlightEntity
import kz.tavr.geo.GeoMath
import org.maplibre.android.offline.OfflineGeometryRegionDefinition
import org.maplibre.android.offline.OfflineManager
import org.maplibre.android.offline.OfflineRegion
import org.maplibre.android.offline.OfflineRegionError
import org.maplibre.android.offline.OfflineRegionStatus
import org.maplibre.geojson.Point
import org.maplibre.geojson.Polygon
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

object MapStyle {
    /** Outdoor-стиль MapTiler: рельеф и горы видны лучше всего. */
    fun url(mapTilerKey: String): String =
        if (mapTilerKey.isNotBlank()) "https://api.maptiler.com/maps/outdoor-v2/style.json?key=$mapTilerKey"
        else "https://demotiles.maplibre.org/style.json" // без ключа — простая карта стран

    fun maxZoom(mapTilerKey: String) = if (mapTilerKey.isNotBlank()) 9.0 else 6.0
}

/**
 * Скачивает тайлы карты вдоль коридора маршрута, чтобы «Карта» работала в самолёте.
 * MapLibre сам кладёт их в свой офлайн-кэш и берёт оттуда без сети.
 */
@Singleton
class OfflineMapManager @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    suspend fun downloadCorridor(
        flight: FlightEntity,
        mapTilerKey: String,
        onProgress: (Int) -> Unit,
    ): Boolean = withContext(Dispatchers.Main) { // OfflineManager работает только на главном потоке
        val manager = OfflineManager.getInstance(context)
        manager.setOfflineMapboxTileCountLimit(20_000)

        val route = GeoMath.greatCircle(flight.dep, flight.arr, 100.0)
        val ring = GeoMath.corridor(route, 170.0).map { Point.fromLngLat(it.lon, it.lat) }
        val definition = OfflineGeometryRegionDefinition(
            MapStyle.url(mapTilerKey),
            Polygon.fromLngLats(listOf(ring)),
            2.0,
            MapStyle.maxZoom(mapTilerKey),
            context.resources.displayMetrics.density,
        )
        val metadata = "flight:${flight.id}".toByteArray()

        suspendCancellableCoroutine { cont ->
            manager.createOfflineRegion(definition, metadata, object : OfflineManager.CreateOfflineRegionCallback {
                override fun onCreate(offlineRegion: OfflineRegion) {
                    cont.invokeOnCancellation { offlineRegion.setDownloadState(OfflineRegion.STATE_INACTIVE) }
                    offlineRegion.setObserver(object : OfflineRegion.OfflineRegionObserver {
                        override fun onStatusChanged(status: OfflineRegionStatus) {
                            if (status.requiredResourceCount > 0) {
                                onProgress((status.completedResourceCount * 100 / status.requiredResourceCount).toInt())
                            }
                            if (status.isComplete && cont.isActive) {
                                offlineRegion.setDownloadState(OfflineRegion.STATE_INACTIVE)
                                cont.resume(true)
                            }
                        }

                        override fun onError(error: OfflineRegionError) {
                            // Отдельные ошибки тайлов не фатальны — MapLibre повторит сам.
                        }

                        override fun mapboxTileCountLimitExceeded(limit: Long) {
                            offlineRegion.setDownloadState(OfflineRegion.STATE_INACTIVE)
                            if (cont.isActive) cont.resume(false)
                        }
                    })
                    offlineRegion.setDownloadState(OfflineRegion.STATE_ACTIVE)
                }

                override fun onError(error: String) {
                    if (cont.isActive) cont.resume(false)
                }
            })
        }
    }
}
