package kz.tavr.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kz.tavr.geo.Fix
import kz.tavr.geo.Motion
import javax.inject.Inject
import javax.inject.Singleton

/** Живое состояние режима полёта для экранов (карта, рейс). */
data class FlightLive(
    val flightId: Long,
    val fix: Fix? = null,
    val motion: Motion? = null,
    /** Позиция оценена без GPS (по расписанию или счислением). */
    val estimated: Boolean = false,
    val night: Boolean = false,
    val nextPoiName: String? = null,
    val nextPoiKm: Int? = null,
)

@Singleton
class FlightSession @Inject constructor() {
    private val _state = MutableStateFlow<FlightLive?>(null)
    val state: StateFlow<FlightLive?> = _state.asStateFlow()

    fun start(flightId: Long) { _state.value = FlightLive(flightId) }
    fun update(transform: (FlightLive) -> FlightLive) { _state.value = _state.value?.let(transform) }
    fun stop() { _state.value = null }
}
