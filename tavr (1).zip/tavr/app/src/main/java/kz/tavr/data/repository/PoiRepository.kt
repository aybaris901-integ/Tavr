package kz.tavr.data.repository

import android.content.Context
import android.util.Log
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kz.tavr.data.local.FlightEntity
import kz.tavr.data.local.PoiDao
import kz.tavr.data.local.PoiEntity
import kz.tavr.data.remote.ChatMessage
import kz.tavr.data.remote.ChatRequest
import kz.tavr.data.remote.CommonsApi
import kz.tavr.data.remote.OpenRouterApi
import kz.tavr.data.remote.Sparql
import kz.tavr.data.remote.WikidataApi
import kz.tavr.data.remote.WikipediaApi
import kz.tavr.data.settings.SettingsRepository
import kz.tavr.domain.DescSource
import kz.tavr.domain.NameSource
import kz.tavr.domain.PoiType
import kz.tavr.geo.GeoMath
import kz.tavr.geo.LatLon
import kz.tavr.geo.Transliterator
import okhttp3.OkHttpClient
import okhttp3.Request
import retrofit2.HttpException
import java.io.File
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicInteger
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs

/** Сырой кандидат из Wikidata (несколько строк SPARQL сливаются в один). */
private data class Candidate(
    val qid: String,
    val type: PoiType,
    val pos: LatLon,
    var elev: Double? = null,
    var pop: Double? = null,
    var areaM2: Double? = null,
    val links: Int,
    var img: String? = null,
    var kk: String? = null,
    var ru: String? = null,
    var en: String? = null,
    var kkTitle: String? = null,
    var ruTitle: String? = null,
    var enTitle: String? = null,
)

@Singleton
class PoiRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val wikidata: WikidataApi,
    private val wikipedia: WikipediaApi,
    private val commons: CommonsApi,
    private val openRouter: OpenRouterApi,
    private val settings: SettingsRepository,
    private val http: OkHttpClient,
    private val dao: PoiDao,
) {
    companion object {
        private const val TAG = "PoiRepository"
        const val CORRIDOR_KM = 150.0
        /** Шаг точек запроса и радиус: при шаге 100 и радиусе 160 коридор ±150 км покрыт без дыр. */
        private const val SAMPLE_STEP_KM = 100.0
        private const val QUERY_RADIUS_KM = 160.0
        private const val MAX_POIS = 150
    }

    private val photoDir get() = File(context.filesDir, "photos").apply { mkdirs() }

    fun observe(flightId: Long) = dao.observeForFlight(flightId)

    suspend fun count(flightId: Long): Int = dao.forFlight(flightId).size

    // ---------------------------------------------------------------- 1. POI вдоль маршрута

    suspend fun collectAlongRoute(flight: FlightEntity, onProgress: suspend (Int) -> Unit): Int = coroutineScope {
        val route = flight.route()
        val samples = GeoMath.sampleAlong(route, SAMPLE_STEP_KM)
        val classes = PoiType.wikidataClasses.keys
        val done = AtomicInteger(0)
        val failed = AtomicInteger(0)
        val gate = Semaphore(3) // WDQS разрешает до 5 параллельных запросов с одного IP

        val rows = samples.map { center ->
            async {
                gate.withPermit {
                    val r = runCatching {
                        withRetry { Sparql.rows(wikidata.sparql(Sparql.poiAroundQuery(center, QUERY_RADIUS_KM, classes))) }
                    }.getOrElse { e ->
                        Log.w(TAG, "SPARQL failed near $center", e)
                        failed.incrementAndGet()
                        emptyList()
                    }
                    onProgress(done.incrementAndGet() * 100 / samples.size)
                    r
                }
            }
        }.awaitAll().flatten()
        // Один-два неудачных запроса не страшны, но если не ответил ни один — это ошибка сети.
        if (failed.get() == samples.size) throw java.io.IOException("Wikidata unavailable")

        val merged = LinkedHashMap<String, Candidate>()
        for (row in rows) {
            val qid = Sparql.qid(row["item"] ?: continue)
            val type = PoiType.wikidataClasses[Sparql.qid(row["cls"] ?: continue)] ?: continue
            val pos = Sparql.point(row["coord"] ?: continue) ?: continue
            val c = merged.getOrPut(qid) {
                Candidate(qid = qid, type = type, pos = pos, links = row["links"]?.toIntOrNull() ?: 0)
            }
            Sparql.num(row["elev"])?.let { e -> c.elev = maxOf(c.elev ?: e, e) }
            Sparql.num(row["pop"])?.let { p -> c.pop = maxOf(c.pop ?: p, p) }
            Sparql.num(row["area"])?.let { a -> c.areaM2 = maxOf(c.areaM2 ?: a, a) }
            c.img = c.img ?: row["img"]
            c.kk = c.kk ?: row["kk"]; c.ru = c.ru ?: row["ru"]; c.en = c.en ?: row["en"]
            c.kkTitle = c.kkTitle ?: row["kkTitle"]
            c.ruTitle = c.ruTitle ?: row["ruTitle"]
            c.enTitle = c.enTitle ?: row["enTitle"]
        }

        val pois = merged.values
            .filter(::isInteresting)
            .mapNotNull { c ->
                val proj = GeoMath.projectOnRoute(route, c.pos)
                if (abs(proj.crossKm) > CORRIDOR_KM) null else c to proj
            }
            .sortedByDescending { it.first.links } // ранжирование по числу sitelinks
            .take(MAX_POIS)
            .map { (c, proj) -> toEntity(flight.id, c, proj.alongKm, proj.crossKm) }

        dao.deleteForFlight(flight.id)
        dao.upsertAll(pois)
        pois.size
    }

    private fun isInteresting(c: Candidate): Boolean {
        val areaKm2 = (c.areaM2 ?: 0.0) / 1e6
        return when (c.type) {
            PoiType.MOUNTAIN -> (c.elev ?: 0.0) > 2000 || (c.elev == null && c.links >= 30)
            PoiType.VOLCANO, PoiType.GLACIER, PoiType.CANYON -> true
            PoiType.LAKE, PoiType.ISLAND -> areaKm2 >= 100 || c.links >= 40
            PoiType.CITY -> (c.pop ?: 0.0) > 1_000_000
        }
    }

    private fun toEntity(flightId: Long, c: Candidate, routeKm: Double, crossKm: Double): PoiEntity {
        val (name, source) = when {
            c.kk != null -> c.kk!! to NameSource.KK
            c.ru != null -> c.ru!! to NameSource.RU // русская кириллица читается и по-казахски
            c.en != null -> Transliterator.latinToKkCyrillic(c.en!!) to NameSource.TRANSLIT
            else -> c.qid to NameSource.ID
        }
        return PoiEntity(
            flightId = flightId,
            qid = c.qid,
            type = c.type,
            name = name,
            nameSource = source,
            lat = c.pos.lat,
            lon = c.pos.lon,
            elevationM = c.elev?.toInt(),
            population = c.pop?.toLong(),
            sitelinks = c.links,
            routeKm = routeKm,
            crossKm = crossKm,
            kkTitle = c.kkTitle,
            ruTitle = c.ruTitle,
            enTitle = c.enTitle,
            nameRu = c.ru,
            nameEn = c.en,
            commonsFile = c.img?.let(::commonsFileTitle),
        )
    }

    // ---------------------------------------------------------------- 2. Описания

    suspend fun fillDescriptions(flightId: Long, onProgress: suspend (Int) -> Unit) = coroutineScope {
        // Только те, у кого ещё нет текста (при повторном запуске не переводим заново).
        val pois = dao.forFlight(flightId).filter { it.description == null && it.sourceText == null }
        val keys = settings.current()
        val gate = Semaphore(4)
        val done = AtomicInteger(0)
        pois.map { poi ->
            async {
                gate.withPermit {
                    runCatching { describe(poi, keys.openRouterKey, keys.openRouterModel) }
                        .onFailure { Log.w(TAG, "describe ${poi.qid}", it) }
                    onProgress(done.incrementAndGet() * 100 / pois.size.coerceAtLeast(1))
                }
            }
        }.awaitAll()
    }

    private suspend fun describe(poi: PoiEntity, llmKey: String, model: String) {
        // а) есть статья в казахской Википедии
        poi.kkTitle?.let { title ->
            val kk = extract("kk", title)
            if (!kk.isNullOrBlank()) {
                val src = poi.ruTitle?.let { extract("ru", it) }?.let { it to "ru" }
                    ?: poi.enTitle?.let { extract("en", it) }?.let { it to "en" }
                dao.setDescription(poi.flightId, poi.qid, shorten(kk), DescSource.KK_WIKI, src?.first, src?.second)
                return
            }
        }
        // б) берём ru/en и переводим через LLM
        val (text, lang) = poi.ruTitle?.let { extract("ru", it) }?.let { it to "ru" }
            ?: poi.enTitle?.let { extract("en", it) }?.let { it to "en" }
            ?: run {
                dao.setDescription(poi.flightId, poi.qid, null, DescSource.NONE, null, null)
                return
            }
        val translated = if (llmKey.isNotBlank()) translateToKazakh(poi, text, lang, llmKey, model) else null
        if (translated != null) {
            dao.setDescription(poi.flightId, poi.qid, translated, DescSource.LLM, text, lang)
        } else {
            val raw = if (lang == "ru") DescSource.RAW_RU else DescSource.RAW_EN
            dao.setDescription(poi.flightId, poi.qid, null, raw, text, lang)
        }
    }

    private suspend fun extract(lang: String, title: String): String? = runCatching {
        val path = URLEncoder.encode(title.replace(' ', '_'), "UTF-8").replace("+", "%20")
        wikipedia.summary("https://$lang.wikipedia.org/api/rest_v1/page/summary/$path").extract
    }.getOrNull()?.trim()?.takeIf { it.length > 20 }?.let(::shorten)

    /** Не больше 3 предложений и ~450 символов. */
    private fun shorten(text: String): String {
        val sentences = text.split(Regex("(?<=[.!?])\\s+"))
        val sb = StringBuilder()
        for (s in sentences.take(3)) {
            if (sb.isNotEmpty() && sb.length + s.length > 450) break
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(s)
        }
        return sb.toString()
    }

    private suspend fun translateToKazakh(
        poi: PoiEntity,
        source: String,
        lang: String,
        key: String,
        model: String,
    ): String? {
        val facts = buildString {
            append("Нысан: ${poi.name} (${poi.type.name.lowercase()})")
            poi.elevationM?.let { append(", биіктігі $it м") }
            poi.population?.let { append(", халқы $it") }
            append(".\nДереккөз (${if (lang == "ru") "орысша" else "ағылшынша"}):\n$source")
        }
        val request = ChatRequest(
            model = model,
            messages = listOf(
                ChatMessage(
                    role = "system",
                    content = "Сен Tavr қосымшасының жолсеріксің: ұшақ терезесінен көрінетін жерлер туралы " +
                        "жолаушыға қазақ тілінде (кирилл жазуымен) қысқа айтып бересің. Тек берілген дереккөзге сүйен, " +
                        "ойдан ештеңе қоспа. 2–3 қысқа, қарапайым әрі қызықты сөйлем жаз, барлығы 350 таңбадан аспасын. " +
                        "Тізім, markdown, тырнақша және сәлемдесу жазба — тек мәтіннің өзін қайтар.",
                ),
                ChatMessage(role = "user", content = facts),
            ),
        )
        return runCatching {
            withRetry(times = 2) { openRouter.complete("Bearer $key", request).choices.firstOrNull()?.message?.content }
        }.onFailure { Log.w(TAG, "LLM ${poi.qid}", it) }.getOrNull()
            ?.trim()?.trim('"', '«', '»')?.replace(Regex("[*#_`]"), "")?.takeIf { it.length > 20 }
    }

    // ---------------------------------------------------------------- 3. Фото с Commons

    suspend fun downloadPhotos(flightId: Long, onProgress: suspend (Int) -> Unit) = coroutineScope {
        val pois = dao.forFlight(flightId).filter { it.commonsFile != null && it.photoPath == null }
        val gate = Semaphore(4)
        val done = AtomicInteger(0)
        pois.map { poi ->
            async {
                gate.withPermit {
                    runCatching { downloadPhoto(poi) }.onFailure { Log.w(TAG, "photo ${poi.qid}", it) }
                    onProgress(done.incrementAndGet() * 100 / pois.size.coerceAtLeast(1))
                }
            }
        }.awaitAll()
    }

    private suspend fun downloadPhoto(poi: PoiEntity) {
        val info = commons.imageInfo(poi.commonsFile!!)
        val ii = info["query"]?.jsonObject?.get("pages")?.jsonArray?.firstOrNull()?.jsonObject
            ?.get("imageinfo")?.jsonArray?.firstOrNull()?.jsonObject ?: return
        val url = (ii["thumburl"] ?: ii["url"])?.jsonPrimitive?.contentOrNull ?: return
        val meta = ii["extmetadata"]?.jsonObject
        fun metaValue(k: String) = meta?.get(k)?.jsonObject?.get("value")?.jsonPrimitive?.contentOrNull
        val author = metaValue("Artist")?.let(::stripHtml)?.take(80)
        val license = metaValue("LicenseShortName")?.let(::stripHtml)

        val file = File(photoDir, "${poi.qid}.jpg")
        withContext(Dispatchers.IO) {
            http.newCall(Request.Builder().url(url).build()).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext
                resp.body?.byteStream()?.use { input -> file.outputStream().use { input.copyTo(it) } }
            }
        }
        if (file.length() > 0) dao.setPhoto(poi.flightId, poi.qid, file.absolutePath, author, license)
    }

    /** "http://commons.wikimedia.org/wiki/Special:FilePath/Khan%20Tengri.jpg" → "File:Khan Tengri.jpg" */
    private fun commonsFileTitle(url: String): String =
        "File:" + URLDecoder.decode(url.substringAfterLast('/'), "UTF-8")

    private fun stripHtml(s: String): String =
        s.replace(Regex("<[^>]+>"), " ")
            .replace("&amp;", "&").replace("&quot;", "\"").replace("&#039;", "'").replace("&nbsp;", " ")
            .replace(Regex("\\s+"), " ").trim()

    // ----------------------------------------------------------------

    private suspend fun <T> withRetry(times: Int = 3, block: suspend () -> T): T {
        var wait = 1500L
        repeat(times - 1) {
            try {
                return block()
            } catch (e: HttpException) {
                if (e.code() != 429 && e.code() < 500) throw e // 429 — WDQS просит притормозить
            } catch (e: java.io.IOException) {
                // сеть моргнула — пробуем ещё раз
            }
            delay(wait)
            wait *= 2
        }
        return block()
    }
}
