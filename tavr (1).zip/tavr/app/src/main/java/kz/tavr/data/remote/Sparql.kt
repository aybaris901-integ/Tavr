package kz.tavr.data.remote

import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kz.tavr.geo.LatLon
import java.util.Locale

/** Разбор ответа SPARQL (application/sparql-results+json). */
object Sparql {

    /** Строки результата: имя переменной → значение. */
    fun rows(response: JsonObject): List<Map<String, String>> =
        response["results"]?.jsonObject?.get("bindings")?.jsonArray.orEmpty().map { row ->
            row.jsonObject.mapNotNull { (k, v) ->
                v.jsonObject["value"]?.jsonPrimitive?.contentOrNull?.let { k to it }
            }.toMap()
        }

    /** "http://www.wikidata.org/entity/Q123" → "Q123" */
    fun qid(uri: String): String = uri.substringAfterLast('/')

    /** WKT "Point(76.9 43.2)" → LatLon(43.2, 76.9) */
    fun point(wkt: String): LatLon? {
        val nums = wkt.substringAfter('(').substringBefore(')').trim().split(Regex("\\s+"))
        if (nums.size != 2) return null
        val lon = nums[0].toDoubleOrNull() ?: return null
        val lat = nums[1].toDoubleOrNull() ?: return null
        return LatLon(lat, lon)
    }

    fun num(v: String?): Double? = v?.toDoubleOrNull()

    private fun d(x: Double) = String.format(Locale.US, "%.5f", x)

    /** Объекты интересных классов в радиусе [radiusKm] вокруг [center]. */
    fun poiAroundQuery(center: LatLon, radiusKm: Double, classes: Collection<String>): String = """
        SELECT ?item ?cls ?coord ?elev ?pop ?area ?links ?img ?kk ?ru ?en ?kkTitle ?ruTitle ?enTitle WHERE {
          SERVICE wikibase:around {
            ?item wdt:P625 ?coord .
            bd:serviceParam wikibase:center "Point(${d(center.lon)} ${d(center.lat)})"^^geo:wktLiteral ;
                            wikibase:radius "${radiusKm.toInt()}" .
          }
          VALUES ?cls { ${classes.joinToString(" ") { "wd:$it" }} }
          ?item wdt:P31 ?cls ;
                wikibase:sitelinks ?links .
          FILTER(?links >= 5)
          OPTIONAL { ?item p:P2044/psn:P2044/wikibase:quantityAmount ?elev . }
          OPTIONAL { ?item wdt:P1082 ?pop . }
          OPTIONAL { ?item p:P2046/psn:P2046/wikibase:quantityAmount ?area . }
          OPTIONAL { ?item wdt:P18 ?img . }
          OPTIONAL { ?item rdfs:label ?kk . FILTER(LANG(?kk) = "kk") }
          OPTIONAL { ?item rdfs:label ?ru . FILTER(LANG(?ru) = "ru") }
          OPTIONAL { ?item rdfs:label ?en . FILTER(LANG(?en) = "en") }
          OPTIONAL { ?a1 schema:about ?item ; schema:isPartOf <https://kk.wikipedia.org/> ; schema:name ?kkTitle . }
          OPTIONAL { ?a2 schema:about ?item ; schema:isPartOf <https://ru.wikipedia.org/> ; schema:name ?ruTitle . }
          OPTIONAL { ?a3 schema:about ?item ; schema:isPartOf <https://en.wikipedia.org/> ; schema:name ?enTitle . }
        }
    """.trimIndent()

    /** Аэропорт по коду IATA (P238). */
    fun airportQuery(iata: String): String = """
        SELECT ?item ?coord ?kk ?ru ?en WHERE {
          ?item wdt:P238 "${iata.uppercase().filter { it.isLetter() }}" ;
                wdt:P625 ?coord .
          OPTIONAL { ?item rdfs:label ?kk . FILTER(LANG(?kk) = "kk") }
          OPTIONAL { ?item rdfs:label ?ru . FILTER(LANG(?ru) = "ru") }
          OPTIONAL { ?item rdfs:label ?en . FILTER(LANG(?en) = "en") }
        } LIMIT 1
    """.trimIndent()
}
