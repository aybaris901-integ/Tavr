package kz.tavr.data.repository

import androidx.annotation.StringRes
import kz.tavr.R
import kz.tavr.data.local.FlightDao
import kz.tavr.data.local.FlightEntity
import kz.tavr.data.remote.AdbTime
import kz.tavr.data.remote.AeroDataBoxApi
import kz.tavr.data.remote.Sparql
import kz.tavr.data.remote.WikidataApi
import kz.tavr.data.settings.SettingsRepository
import kz.tavr.domain.FlightStatus
import kz.tavr.domain.RouteSource
import kz.tavr.geo.LatLon
import kz.tavr.geo.SeatSide
import kz.tavr.geo.Transliterator
import retrofit2.HttpException
import java.io.IOException
import java.time.OffsetDateTime
import javax.inject.Inject
import javax.inject.Singleton

sealed interface ResolveResult {
    data class Ok(val flightId: Long) : ResolveResult
    data class Error(@StringRes val message: Int, val arg: String? = null) : ResolveResult
}

private data class Airport(val code: String, val name: String, val pos: LatLon)

/**
 * Находит рейс: AeroDataBox (аэропорты + расписание), иначе — аэропорты, введённые вручную.
 * В обоих случаях плановый маршрут — дуга большого круга (AeroDataBox не отдаёт путевые точки).
 */
@Singleton
class FlightRepository @Inject constructor(
    private val adb: AeroDataBoxApi,
    private val wikidata: WikidataApi,
    private val settings: SettingsRepository,
    private val flights: FlightDao,
) {
    fun observeLatest() = flights.observeLatest()

    suspend fun resolve(
        rawNumber: String,
        date: String,
        seat: SeatSide,
        manualDep: String?,
        manualArr: String?,
    ): ResolveResult {
        val number = rawNumber.uppercase().filter { it.isLetterOrDigit() }
        val manual = !manualDep.isNullOrBlank() || !manualArr.isNullOrBlank()
        return try {
            if (manual) resolveManual(number, date, seat, manualDep.orEmpty(), manualArr.orEmpty())
            else resolveAdb(number, date, seat)
        } catch (e: IOException) {
            ResolveResult.Error(R.string.err_network)
        } catch (e: HttpException) {
            if (e.code() in listOf(204, 404)) ResolveResult.Error(R.string.err_flight_not_found)
            else ResolveResult.Error(R.string.err_network)
        }
    }

    private suspend fun resolveAdb(number: String, date: String, seat: SeatSide): ResolveResult {
        if (number.isBlank()) return ResolveResult.Error(R.string.err_flight_number)
        val key = settings.current().aeroDataBoxKey
        if (key.isBlank()) return ResolveResult.Error(R.string.err_no_aerodatabox_key)

        val f = adb.flight(number, date, key).firstOrNull {
            it.departure?.airport?.location != null && it.arrival?.airport?.location != null
        } ?: return ResolveResult.Error(R.string.err_flight_not_found)

        val dep = f.departure!!.airport!!
        val arr = f.arrival!!.airport!!
        val id = flights.insert(
            FlightEntity(
                number = number,
                date = date,
                seat = seat,
                depCode = dep.iata ?: dep.icao.orEmpty(),
                depName = dep.municipalityName ?: dep.name.orEmpty(),
                depLat = dep.location!!.lat,
                depLon = dep.location.lon,
                arrCode = arr.iata ?: arr.icao.orEmpty(),
                arrName = arr.municipalityName ?: arr.name.orEmpty(),
                arrLat = arr.location!!.lat,
                arrLon = arr.location.lon,
                depTimeUtc = parseUtc(f.departure.scheduledTime),
                arrTimeUtc = parseUtc(f.arrival.scheduledTime),
                routeSource = RouteSource.AERODATABOX,
                status = FlightStatus.PREPARING,
            ),
        )
        return ResolveResult.Ok(id)
    }

    private suspend fun resolveManual(
        number: String,
        date: String,
        seat: SeatSide,
        depCode: String,
        arrCode: String,
    ): ResolveResult {
        if (depCode.isBlank() || arrCode.isBlank()) return ResolveResult.Error(R.string.err_need_airports)
        val dep = airport(depCode) ?: return ResolveResult.Error(R.string.err_airport_not_found, depCode.uppercase())
        val arr = airport(arrCode) ?: return ResolveResult.Error(R.string.err_airport_not_found, arrCode.uppercase())
        val id = flights.insert(
            FlightEntity(
                number = number.ifBlank { "${dep.code}-${arr.code}" },
                date = date,
                seat = seat,
                depCode = dep.code, depName = dep.name, depLat = dep.pos.lat, depLon = dep.pos.lon,
                arrCode = arr.code, arrName = arr.name, arrLat = arr.pos.lat, arrLon = arr.pos.lon,
                depTimeUtc = null,
                arrTimeUtc = null,
                routeSource = RouteSource.MANUAL,
                status = FlightStatus.PREPARING,
            ),
        )
        return ResolveResult.Ok(id)
    }

    private suspend fun airport(code: String): Airport? {
        val row = Sparql.rows(wikidata.sparql(Sparql.airportQuery(code))).firstOrNull() ?: return null
        val pos = row["coord"]?.let(Sparql::point) ?: return null
        val name = row["kk"] ?: row["ru"] ?: row["en"]?.let(Transliterator::latinToKkCyrillic) ?: code
        return Airport(code.uppercase(), name, pos)
    }

    /** "2026-11-05 03:40Z" → epoch ms. */
    private fun parseUtc(t: AdbTime?): Long? = t?.utc?.let { raw ->
        runCatching { OffsetDateTime.parse(raw.trim().replace(' ', 'T')).toInstant().toEpochMilli() }.getOrNull()
    }
}
