package kz.tavr.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kz.tavr.domain.DescSource
import kz.tavr.domain.FlightStatus
import kz.tavr.domain.NameSource
import kz.tavr.domain.PoiType
import kz.tavr.domain.RouteSource
import kz.tavr.geo.GeoMath
import kz.tavr.geo.LatLon
import kz.tavr.geo.SeatSide
import kz.tavr.geo.Side

@Entity(tableName = "flights")
data class FlightEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val number: String,
    /** Дата вылета, yyyy-MM-dd (местная). */
    val date: String,
    val seat: SeatSide,
    val depCode: String,
    val depName: String,
    val depLat: Double,
    val depLon: Double,
    val arrCode: String,
    val arrName: String,
    val arrLat: Double,
    val arrLon: Double,
    val depTimeUtc: Long?,
    val arrTimeUtc: Long?,
    val routeSource: RouteSource,
    val status: FlightStatus,
    val tilesReady: Boolean = false,
    val poiCount: Int = 0,
    val error: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
) {
    val dep get() = LatLon(depLat, depLon)
    val arr get() = LatLon(arrLat, arrLon)
    val distanceKm get() = GeoMath.distanceKm(dep, arr)

    /** Плановый маршрут: дуга большого круга с шагом 25 км. */
    fun route(): List<LatLon> = GeoMath.greatCircle(dep, arr, 25.0)
}

@Entity(
    tableName = "pois",
    primaryKeys = ["flightId", "qid"],
    indices = [Index("flightId")],
)
data class PoiEntity(
    val flightId: Long,
    val qid: String,
    val type: PoiType,
    /** Название на казахском (кириллица). */
    val name: String,
    val nameSource: NameSource,
    val lat: Double,
    val lon: Double,
    val elevationM: Int?,
    val population: Long?,
    val sitelinks: Int,
    /** Положение вдоль планового маршрута, км от вылета. */
    val routeKm: Double,
    /** Смещение от маршрута, км: > 0 справа, < 0 слева. */
    val crossKm: Double,
    val kkTitle: String?,
    val ruTitle: String?,
    val enTitle: String?,
    /** Метки для русского и английского интерфейса. */
    val nameRu: String? = null,
    val nameEn: String? = null,
    /** Описание на казахском (кириллица). */
    val description: String? = null,
    val descSource: DescSource = DescSource.NONE,
    /** Исходная выдержка из Википедии (для ru/en интерфейса) и её язык. */
    val sourceText: String? = null,
    val sourceLang: String? = null,
    /** Имя файла на Commons (P18). */
    val commonsFile: String? = null,
    val photoPath: String? = null,
    val photoAuthor: String? = null,
    val photoLicense: String? = null,
    /** Когда пассажиру сказали об объекте (null — ещё впереди). */
    val seenAt: Long? = null,
    val seenSide: Side? = null,
) {
    val position get() = LatLon(lat, lon)
}

@Entity(tableName = "track", indices = [Index("flightId")])
data class TrackPointEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val flightId: Long,
    val time: Long,
    val lat: Double,
    val lon: Double,
    val altitudeM: Double?,
    val speedKmh: Double?,
    val bearingDeg: Double?,
    /** true — точка оценена по расписанию, а не по GPS. */
    val estimated: Boolean = false,
)

@Entity(tableName = "kp")
data class KpEntity(
    /** Начало 3-часового интервала, UTC мс. */
    @PrimaryKey val time: Long,
    val kp: Double,
    val observed: Boolean,
)
