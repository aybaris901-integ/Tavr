package kz.tavr.data.repository

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import kz.tavr.data.local.KpDao
import kz.tavr.data.local.KpEntity
import kz.tavr.data.remote.NoaaApi
import java.time.LocalDateTime
import java.time.ZoneOffset
import javax.inject.Inject
import javax.inject.Singleton

/** Прогноз Kp-индекса NOAA SWPC — для подсказок о северном сиянии в офлайне. */
@Singleton
class SpaceWeatherRepository @Inject constructor(
    private val api: NoaaApi,
    private val dao: KpDao,
) {
    suspend fun refresh(): Int {
        val items = parse(api.kpForecast())
        if (items.isNotEmpty()) dao.replaceAll(items)
        return items.size
    }

    suspend fun kpAt(time: Long): Double? = dao.at(time)?.kp

    /**
     * Поддерживает оба формата SWPC:
     *  - массив массивов с заголовком: [["time_tag","kp","observed","noaa_scale"], ["2026-11-03 00:00:00","2.67","observed",null], …]
     *  - массив объектов: [{"time_tag":"2026-11-03T00:00:00","kp":2.67,"observed":"observed"}, …]
     */
    internal fun parse(root: JsonElement): List<KpEntity> {
        val arr = root as? JsonArray ?: return emptyList()
        if (arr.isEmpty()) return emptyList()
        return when (arr.first()) {
            is JsonArray -> {
                val header = (arr.first() as JsonArray).map { it.str() }
                val iTime = header.indexOf("time_tag")
                val iKp = header.indexOf("kp")
                val iObs = header.indexOf("observed")
                if (iTime < 0 || iKp < 0) return emptyList()
                arr.drop(1).mapNotNull { row ->
                    val r = row as? JsonArray ?: return@mapNotNull null
                    entity(r.getOrNull(iTime)?.str(), r.getOrNull(iKp)?.str(), r.getOrNull(iObs)?.str())
                }
            }
            is JsonObject -> arr.mapNotNull { el ->
                val o = el as? JsonObject ?: return@mapNotNull null
                entity(o["time_tag"]?.str(), o["kp"]?.str(), o["observed"]?.str())
            }
            else -> emptyList()
        }
    }

    private fun entity(time: String?, kp: String?, observed: String?): KpEntity? {
        val t = time?.let(::parseTime) ?: return null
        val k = kp?.toDoubleOrNull() ?: return null
        return KpEntity(time = t, kp = k, observed = observed == "observed")
    }

    private fun parseTime(s: String): Long? = runCatching {
        LocalDateTime.parse(s.trim().removeSuffix("Z").replace(' ', 'T'))
            .toInstant(ZoneOffset.UTC).toEpochMilli()
    }.getOrNull()

    private fun JsonElement.str(): String? = (this as? JsonPrimitive)?.contentOrNull ?: runCatching {
        jsonPrimitive.contentOrNull
    }.getOrNull()
}
