package kz.tavr.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kz.tavr.R
import kz.tavr.data.local.PoiEntity
import kz.tavr.domain.Lang
import kz.tavr.domain.PoiType
import kz.tavr.geo.ClockDirection
import kz.tavr.geo.Side
import kz.tavr.ui.theme.Gold
import kz.tavr.ui.theme.Sky
import kz.tavr.ui.theme.SkyDeep
import java.io.File
import java.text.NumberFormat

/** Шапка: небо, золотое солнце, горный силуэт. */
@Composable
fun MountainHeader(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(150.dp)
            .background(Brush.verticalGradient(listOf(SkyDeep, Sky))),
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawCircle(Gold, radius = h * 0.13f, center = Offset(w * 0.78f, h * 0.32f))
            val back = Path().apply {
                moveTo(0f, h * 0.85f); lineTo(w * 0.22f, h * 0.48f); lineTo(w * 0.32f, h * 0.6f)
                lineTo(w * 0.5f, h * 0.36f); lineTo(w * 0.72f, h * 0.66f); lineTo(w, h * 0.5f)
                lineTo(w, h); lineTo(0f, h); close()
            }
            drawPath(back, Color.White.copy(alpha = 0.35f))
            val front = Path().apply {
                moveTo(0f, h); lineTo(0f, h * 0.9f); lineTo(w * 0.15f, h * 0.7f); lineTo(w * 0.27f, h * 0.82f)
                lineTo(w * 0.42f, h * 0.58f); lineTo(w * 0.6f, h * 0.84f); lineTo(w * 0.7f, h * 0.76f)
                lineTo(w, h * 0.95f); lineTo(w, h); close()
            }
            drawPath(front, Color.White)
        }
        Column(Modifier.padding(start = 20.dp, top = 28.dp)) {
            Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineMedium, color = Color.White)
            Text(
                stringResource(R.string.slogan).substringAfter("— "),
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.9f),
            )
        }
    }
}

@Composable
fun Pill(text: String, container: Color, content: Color, modifier: Modifier = Modifier) {
    Surface(color = container, contentColor = content, shape = RoundedCornerShape(50), modifier = modifier) {
        Text(text, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
    }
}

@Composable
fun sideLabel(side: Side): String = stringResource(
    when (side) {
        Side.LEFT -> R.string.side_left
        Side.RIGHT -> R.string.side_right
        Side.BELOW -> R.string.side_below
    },
)

/** Карточка объекта для «Таспа». */
@Composable
fun PoiCard(poi: PoiEntity, kmAhead: Int?, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val (description, note) = Lang.poiDescription(ctx, poi)
    val side = poi.seenSide ?: ClockDirection.side(poi.crossKm)
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        if (poi.photoPath != null) {
            AsyncImage(
                model = File(poi.photoPath),
                contentDescription = Lang.poiName(ctx, poi),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
            )
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Pill(stringResource(poi.type.label), MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                Pill(sideLabel(side), MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
                if (kmAhead != null && kmAhead > 0) {
                    Text(stringResource(R.string.km_ahead, kmAhead), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text(Lang.poiName(ctx, poi), style = MaterialTheme.typography.titleLarge)
            facts(poi)?.let { Text(it, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) }
            Text(description, style = MaterialTheme.typography.bodyMedium)
            note?.let {
                Text(stringResource(it), style = MaterialTheme.typography.labelSmall, fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (poi.photoPath != null && (poi.photoAuthor != null || poi.photoLicense != null)) {
                Text(
                    stringResource(R.string.photo_credit, poi.photoAuthor ?: "Wikimedia Commons", poi.photoLicense ?: "—"),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun facts(poi: PoiEntity): String? = when {
    poi.elevationM != null && poi.type in setOf(PoiType.MOUNTAIN, PoiType.VOLCANO) ->
        stringResource(R.string.elevation_m, poi.elevationM)
    poi.population != null && poi.type == PoiType.CITY ->
        stringResource(R.string.population_fmt, NumberFormat.getIntegerInstance().format(poi.population))
    else -> null
}
