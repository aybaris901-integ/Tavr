package kz.tavr.ui.flight

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkInfo
import androidx.work.WorkManager
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kz.tavr.data.local.FlightEntity
import kz.tavr.data.repository.FlightRepository
import kz.tavr.data.repository.ResolveResult
import kz.tavr.geo.SeatSide
import kz.tavr.service.FlightLive
import kz.tavr.service.FlightModeService
import kz.tavr.service.FlightSession
import kz.tavr.work.PrepStep
import kz.tavr.work.PrepareFlightWorker
import java.time.LocalDate
import javax.inject.Inject

data class FlightForm(
    val number: String = "",
    val date: LocalDate = LocalDate.now(),
    val seat: SeatSide = SeatSide.BOTH,
    val manualAirports: Boolean = false,
    val dep: String = "",
    val arr: String = "",
    val busy: Boolean = false,
    val error: ResolveResult.Error? = null,
    /** Показать форму, даже если уже есть рейс («Жаңа рейс»). */
    val editing: Boolean = false,
)

data class PrepProgress(
    val step: PrepStep = PrepStep.POI,
    val percent: Int = 0,
    val running: Boolean = false,
    val tilesSkipped: Boolean = false,
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class FlightViewModel @Inject constructor(
    @ApplicationContext private val app: Context,
    private val repo: FlightRepository,
    session: FlightSession,
) : ViewModel() {

    private val _form = MutableStateFlow(FlightForm())
    val form: StateFlow<FlightForm> = _form.asStateFlow()

    val flight: StateFlow<FlightEntity?> = repo.observeLatest()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val live: StateFlow<FlightLive?> = session.state

    val progress: StateFlow<PrepProgress> = flight
        .map { it?.id }
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else WorkManager.getInstance(app).getWorkInfosForUniqueWorkFlow(PrepareFlightWorker.uniqueName(id))
        }
        .map { infos ->
            val info = infos.firstOrNull() ?: return@map PrepProgress()
            val data = if (info.state.isFinished) info.outputData else info.progress
            PrepProgress(
                step = PrepStep.entries.getOrElse(data.getInt(PrepareFlightWorker.KEY_STEP, 1)) { PrepStep.POI },
                percent = data.getInt(PrepareFlightWorker.KEY_PERCENT, 0),
                running = info.state == WorkInfo.State.RUNNING || info.state == WorkInfo.State.ENQUEUED,
                tilesSkipped = data.getBoolean(PrepareFlightWorker.KEY_TILES_SKIPPED, false),
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PrepProgress())

    fun edit(transform: (FlightForm) -> FlightForm) = _form.update { transform(it).copy(error = null) }

    fun prepare() {
        val f = _form.value
        if (f.busy) return
        _form.update { it.copy(busy = true, error = null) }
        viewModelScope.launch {
            val result = repo.resolve(
                rawNumber = f.number,
                date = f.date.toString(),
                seat = f.seat,
                manualDep = f.dep.takeIf { f.manualAirports },
                manualArr = f.arr.takeIf { f.manualAirports },
            )
            when (result) {
                is ResolveResult.Ok -> {
                    PrepareFlightWorker.enqueue(app, result.flightId)
                    _form.update { it.copy(busy = false, editing = false) }
                }
                is ResolveResult.Error -> _form.update {
                    // Рейс не нашёлся — сразу открываем ручной ввод аэропортов.
                    it.copy(busy = false, error = result, manualAirports = true)
                }
            }
        }
    }

    fun retryPrepare() {
        flight.value?.let { PrepareFlightWorker.enqueue(app, it.id) }
    }

    fun newFlight() = _form.update { FlightForm(editing = true) }

    fun cancelNewFlight() = _form.update { it.copy(editing = false) }

    fun startFlightMode(context: Context) {
        flight.value?.let { FlightModeService.start(context, it.id) }
    }

    fun stopFlightMode(context: Context) = FlightModeService.stop(context)
}
