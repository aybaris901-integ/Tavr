package kz.tavr.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow
import kz.tavr.domain.DescSource
import kz.tavr.domain.FlightStatus
import kz.tavr.geo.Side

@Dao
interface FlightDao {
    @Insert
    suspend fun insert(flight: FlightEntity): Long

    @Update
    suspend fun update(flight: FlightEntity)

    @Query("SELECT * FROM flights WHERE id = :id")
    suspend fun get(id: Long): FlightEntity?

    @Query("SELECT * FROM flights WHERE id = :id")
    fun observe(id: Long): Flow<FlightEntity?>

    @Query("SELECT * FROM flights ORDER BY createdAt DESC LIMIT 1")
    fun observeLatest(): Flow<FlightEntity?>

    @Query("SELECT * FROM flights ORDER BY createdAt DESC LIMIT 1")
    suspend fun latest(): FlightEntity?

    @Query("UPDATE flights SET status = :status, error = :error WHERE id = :id")
    suspend fun setStatus(id: Long, status: FlightStatus, error: String? = null)

    @Query("UPDATE flights SET tilesReady = :ready WHERE id = :id")
    suspend fun setTilesReady(id: Long, ready: Boolean)

    @Query("UPDATE flights SET poiCount = :count WHERE id = :id")
    suspend fun setPoiCount(id: Long, count: Int)
}

@Dao
interface PoiDao {
    @Upsert
    suspend fun upsertAll(pois: List<PoiEntity>)

    @Query("DELETE FROM pois WHERE flightId = :flightId")
    suspend fun deleteForFlight(flightId: Long)

    @Query("SELECT * FROM pois WHERE flightId = :flightId ORDER BY routeKm")
    suspend fun forFlight(flightId: Long): List<PoiEntity>

    @Query("SELECT * FROM pois WHERE flightId = :flightId ORDER BY routeKm")
    fun observeForFlight(flightId: Long): Flow<List<PoiEntity>>

    @Query("SELECT * FROM pois WHERE flightId = :flightId AND seenAt IS NULL ORDER BY routeKm")
    suspend fun pending(flightId: Long): List<PoiEntity>

    @Query("UPDATE pois SET seenAt = :time, seenSide = :side WHERE flightId = :flightId AND qid = :qid")
    suspend fun markSeen(flightId: Long, qid: String, time: Long, side: Side)

    @Query(
        "UPDATE pois SET description = :text, descSource = :source, sourceText = :sourceText, " +
            "sourceLang = :sourceLang WHERE flightId = :flightId AND qid = :qid",
    )
    suspend fun setDescription(
        flightId: Long,
        qid: String,
        text: String?,
        source: DescSource,
        sourceText: String?,
        sourceLang: String?,
    )

    @Query(
        "UPDATE pois SET photoPath = :path, photoAuthor = :author, photoLicense = :license " +
            "WHERE flightId = :flightId AND qid = :qid",
    )
    suspend fun setPhoto(flightId: Long, qid: String, path: String, author: String?, license: String?)
}

@Dao
interface TrackDao {
    @Insert
    suspend fun insert(point: TrackPointEntity)

    @Query("SELECT * FROM track WHERE flightId = :flightId AND time >= :since ORDER BY time")
    suspend fun since(flightId: Long, since: Long): List<TrackPointEntity>

    @Query("SELECT * FROM track WHERE flightId = :flightId ORDER BY time")
    fun observe(flightId: Long): Flow<List<TrackPointEntity>>

    @Query("SELECT * FROM track WHERE flightId = :flightId AND estimated = 0 ORDER BY time DESC LIMIT 1")
    suspend fun lastGps(flightId: Long): TrackPointEntity?
}

@Dao
interface KpDao {
    @Query("DELETE FROM kp")
    suspend fun clear()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<KpEntity>)

    @Transaction
    suspend fun replaceAll(items: List<KpEntity>) {
        clear()
        insertAll(items)
    }

    /** Kp для момента [time]: интервал, начавшийся не позже [time]. */
    @Query("SELECT * FROM kp WHERE time <= :time ORDER BY time DESC LIMIT 1")
    suspend fun at(time: Long): KpEntity?
}
