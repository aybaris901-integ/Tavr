package kz.tavr.ui.map

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.MyLocation
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kz.tavr.R
import kz.tavr.data.cache.MapStyle
import kz.tavr.data.local.FlightDao
import kz.tavr.data.local.FlightEntity
import kz.tavr.data.local.PoiDao
import kz.tavr.data.local.PoiEntity
import kz.tavr.data.local.TrackDao
import kz.tavr.data.local.TrackPointEntity
import kz.tavr.data.settings.SettingsRepository
import kz.tavr.domain.Lang
import kz.tavr.service.FlightLive
import kz.tavr.service.FlightSession
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point
import javax.inject.Inject

data class MapState(
    val flight: FlightEntity? = null,
    val pois: List<PoiEntity> = emptyList(),
    val track: List<TrackPointEntity> = emptyList(),
    val live: FlightLive? = null,
    val mapTilerKey: String = "",
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class MapViewModel @Inject constructor(
    flights: FlightDao,
    pois: PoiDao,
    track: TrackDao,
    session: FlightSession,
    settings: SettingsRepository,
) : ViewModel() {
    val state: StateFlow<MapState> = combine(flights.observeLatest(), settings.keys) { f, k -> f to k.mapTilerKey }
        .flatMapLatest { (flight, key) ->
            if (flight == null) flowOf(MapState(mapTilerKey = key))
            else combine(pois.observeForFlight(flight.id), track.observe(flight.id), session.state) { p, t, live ->
                MapState(flight, p, t, live, key)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MapState())
}

private const val SRC_ROUTE = "route"
private const val SRC_TRACK = "track"
private const val SRC_POI = "poi"
private const val SRC_PLANE = "plane"
private const val IMG_PLANE = "plane-icon"

@Composable
fun MapScreen(vm: MapViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val mapView = remember { MapView(context).apply { onCreate(null) } }
    var map by remember { mutableStateOf<MapLibreMap?>(null) }
    var style by remember { mutableStateOf<Style?>(null) }

    // Жизненный цикл MapView
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            mapView.onDestroy()
        }
    }

    // Стиль: тот же URL, что при офлайн-загрузке, — тогда тайлы берутся из кэша без сети.
    val styleUrl = MapStyle.url(state.mapTilerKey)
    LaunchedEffect(styleUrl) {
        style = null
        mapView.getMapAsync { m ->
            map = m
            m.uiSettings.isCompassEnabled = true
            m.setStyle(Style.Builder().fromUri(styleUrl)) { s ->
                setupLayers(context, s, mapTiler = state.mapTilerKey.isNotBlank())
                style = s
            }
        }
    }

    // Данные → источники карты
    val ctx = LocalContext.current
    LaunchedEffect(style, state) {
        val s = style ?: return@LaunchedEffect
        val flight = state.flight ?: return@LaunchedEffect
        s.getSourceAs<GeoJsonSource>(SRC_ROUTE)?.setGeoJson(
            LineString.fromLngLats(flight.route().map { Point.fromLngLat(it.lon, it.lat) }),
        )
        val trackSource = s.getSourceAs<GeoJsonSource>(SRC_TRACK)
        if (state.track.size >= 2) {
            trackSource?.setGeoJson(LineString.fromLngLats(state.track.map { Point.fromLngLat(it.lon, it.lat) }))
        } else {
            trackSource?.setGeoJson(FeatureCollection.fromFeatures(emptyList()))
        }
        s.getSourceAs<GeoJsonSource>(SRC_POI)?.setGeoJson(
            FeatureCollection.fromFeatures(
                state.pois.map { p ->
                    Feature.fromGeometry(Point.fromLngLat(p.lon, p.lat)).apply {
                        addStringProperty("name", Lang.poiName(ctx, p))
                        addBooleanProperty("seen", p.seenSide != null)
                    }
                },
            ),
        )
        val fix = state.live?.fix
        val planeSource = s.getSourceAs<GeoJsonSource>(SRC_PLANE)
        if (fix == null) {
            planeSource?.setGeoJson(FeatureCollection.fromFeatures(emptyList()))
        } else {
            planeSource?.setGeoJson(
                Feature.fromGeometry(Point.fromLngLat(fix.lon, fix.lat)).apply {
                    addNumberProperty("bearing", state.live?.motion?.courseDeg ?: 0.0)
                },
            )
        }
    }

    // Первый раз — показать весь маршрут
    var framed by remember { mutableStateOf<Long?>(null) }
    LaunchedEffect(style, state.flight?.id) {
        val m = map ?: return@LaunchedEffect
        val f = state.flight ?: return@LaunchedEffect
        if (style == null || framed == f.id) return@LaunchedEffect
        val bounds = LatLngBounds.Builder().include(LatLng(f.depLat, f.depLon)).include(LatLng(f.arrLat, f.arrLon)).build()
        m.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 120))
        framed = f.id
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(factory = { mapView }, modifier = Modifier.fillMaxSize())

        val banner = when {
            state.flight == null -> stringResource(R.string.map_no_flight)
            state.mapTilerKey.isBlank() -> stringResource(R.string.map_no_key)
            else -> null
        }
        banner?.let {
            Surface(
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier
                    .statusBarsPadding()
                    .padding(12.dp)
                    .align(Alignment.TopCenter),
            ) { Text(it, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), style = MaterialTheme.typography.bodyMedium) }
        }

        state.live?.fix?.let { fix ->
            FloatingActionButton(
                onClick = { map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(fix.lat, fix.lon), 7.0)) },
                containerColor = MaterialTheme.colorScheme.secondary,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp),
            ) { Icon(Icons.Outlined.MyLocation, contentDescription = null) }
        }
    }
}

private fun setupLayers(context: android.content.Context, style: Style, mapTiler: Boolean) {
    val font = if (mapTiler) arrayOf("Noto Sans Regular") else arrayOf("Open Sans Semibold")
    val sky = "#007C90"
    val gold = "#FEC50C"

    style.addSource(GeoJsonSource(SRC_ROUTE))
    style.addSource(GeoJsonSource(SRC_TRACK))
    style.addSource(GeoJsonSource(SRC_POI))
    style.addSource(GeoJsonSource(SRC_PLANE))

    ContextCompat.getDrawable(context, R.drawable.ic_plane)?.let { d ->
        val bmp = Bitmap.createBitmap(d.intrinsicWidth, d.intrinsicHeight, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, bmp.width, bmp.height)
        d.draw(Canvas(bmp))
        style.addImage(IMG_PLANE, bmp)
    }

    style.addLayer(
        LineLayer("route-line", SRC_ROUTE).withProperties(
            PropertyFactory.lineColor(sky),
            PropertyFactory.lineWidth(2f),
            PropertyFactory.lineDasharray(arrayOf(2f, 2f)),
        ),
    )
    style.addLayer(
        LineLayer("track-line", SRC_TRACK).withProperties(
            PropertyFactory.lineColor(gold),
            PropertyFactory.lineWidth(4f),
            PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
        ),
    )
    style.addLayer(
        CircleLayer("poi-dot", SRC_POI).withProperties(
            PropertyFactory.circleRadius(6f),
            PropertyFactory.circleColor(
                Expression.switchCase(Expression.get("seen"), Expression.literal(gold), Expression.literal(sky)),
            ),
            PropertyFactory.circleStrokeColor("#FFFFFF"),
            PropertyFactory.circleStrokeWidth(2f),
        ),
    )
    style.addLayer(
        SymbolLayer("poi-label", SRC_POI).withProperties(
            PropertyFactory.textField(Expression.get("name")),
            PropertyFactory.textFont(font),
            PropertyFactory.textSize(12f),
            PropertyFactory.textOffset(arrayOf(0f, 1.2f)),
            PropertyFactory.textAnchor(Property.TEXT_ANCHOR_TOP),
            PropertyFactory.textColor("#0B1E2B"),
            PropertyFactory.textHaloColor("#FFFFFF"),
            PropertyFactory.textHaloWidth(1.5f),
            PropertyFactory.textOptional(true),
        ),
    )
    style.addLayer(
        SymbolLayer("plane", SRC_PLANE).withProperties(
            PropertyFactory.iconImage(IMG_PLANE),
            PropertyFactory.iconRotate(Expression.get("bearing")),
            PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
            PropertyFactory.iconAllowOverlap(true),
            PropertyFactory.iconIgnorePlacement(true),
        ),
    )
}
