package kz.tavr.ui.feed

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kz.tavr.R
import kz.tavr.data.local.FlightDao
import kz.tavr.data.local.PoiDao
import kz.tavr.data.local.PoiEntity
import kz.tavr.geo.GeoMath
import kz.tavr.service.FlightSession
import kz.tavr.ui.components.PoiCard
import javax.inject.Inject

data class FeedState(
    val upcoming: List<PoiEntity> = emptyList(),
    val seen: List<PoiEntity> = emptyList(),
    /** Где сейчас самолёт на плановом маршруте, км от вылета. */
    val planeRouteKm: Double? = null,
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class FeedViewModel @Inject constructor(
    flights: FlightDao,
    pois: PoiDao,
    session: FlightSession,
) : ViewModel() {
    val state: StateFlow<FeedState> = flights.observeLatest()
        .flatMapLatest { flight ->
            if (flight == null) return@flatMapLatest flowOf(FeedState())
            val route = flight.route()
            combine(pois.observeForFlight(flight.id), session.state) { list, live ->
                val planeKm = live?.fix?.let { GeoMath.projectOnRoute(route, it.latLon).alongKm }
                FeedState(
                    upcoming = list.filter { it.seenAt == null && (planeKm == null || it.routeKm >= planeKm - 20) },
                    seen = list.filter { it.seenSide != null }.sortedByDescending { it.seenAt },
                    planeRouteKm = planeKm,
                )
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), FeedState())
}

@Composable
fun FeedScreen(vm: FeedViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = {
                Text(stringResource(R.string.feed_upcoming) + " · ${state.upcoming.size}")
            })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = {
                Text(stringResource(R.string.feed_seen) + " · ${state.seen.size}")
            })
        }
        val items = if (tab == 0) state.upcoming else state.seen
        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    stringResource(if (tab == 0) R.string.feed_empty_upcoming else R.string.feed_empty_seen),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                items(items, key = { it.qid }) { poi ->
                    val km = if (tab == 0) (poi.routeKm - (state.planeRouteKm ?: 0.0)).toInt() else null
                    PoiCard(poi, km)
                }
            }
        }
    }
}
