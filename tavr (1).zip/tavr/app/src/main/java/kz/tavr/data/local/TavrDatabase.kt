package kz.tavr.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [FlightEntity::class, PoiEntity::class, TrackPointEntity::class, KpEntity::class],
    version = 1,
    exportSchema = true,
)
abstract class TavrDatabase : RoomDatabase() {
    abstract fun flights(): FlightDao
    abstract fun pois(): PoiDao
    abstract fun track(): TrackDao
    abstract fun kp(): KpDao
}
