package kz.tavr.di

import android.content.Context
import androidx.room.Room
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.serialization.json.Json
import kz.tavr.data.local.TavrDatabase
import kz.tavr.data.remote.AeroDataBoxApi
import kz.tavr.data.remote.CommonsApi
import kz.tavr.data.remote.NoaaApi
import kz.tavr.data.remote.OpenRouterApi
import kz.tavr.data.remote.WikidataApi
import kz.tavr.data.remote.WikipediaApi
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    /** Wikimedia требует осмысленный User-Agent. */
    private const val USER_AGENT = "Tavr/0.1 (Android; kz.tavr; window-seat sightseeing app)"

    @Provides @Singleton
    fun json(): Json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        coerceInputValues = true
    }

    @Provides @Singleton
    fun okHttp(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(70, TimeUnit.SECONDS) // SPARQL-запросы бывают долгими
        .addInterceptor { chain ->
            chain.proceed(chain.request().newBuilder().header("User-Agent", USER_AGENT).build())
        }
        .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC })
        .build()

    private inline fun <reified T> api(baseUrl: String, client: OkHttpClient, json: Json): T =
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(T::class.java)

    @Provides @Singleton
    fun aeroDataBox(c: OkHttpClient, j: Json): AeroDataBoxApi = api("https://aerodatabox.p.rapidapi.com/", c, j)

    @Provides @Singleton
    fun wikidata(c: OkHttpClient, j: Json): WikidataApi = api("https://query.wikidata.org/", c, j)

    @Provides @Singleton
    fun wikipedia(c: OkHttpClient, j: Json): WikipediaApi = api("https://wikipedia.org/", c, j)

    @Provides @Singleton
    fun commons(c: OkHttpClient, j: Json): CommonsApi = api("https://commons.wikimedia.org/", c, j)

    @Provides @Singleton
    fun noaa(c: OkHttpClient, j: Json): NoaaApi = api("https://services.swpc.noaa.gov/", c, j)

    @Provides @Singleton
    fun openRouter(c: OkHttpClient, j: Json): OpenRouterApi = api("https://openrouter.ai/api/v1/", c, j)

    @Provides @Singleton
    fun db(@ApplicationContext ctx: Context): TavrDatabase =
        Room.databaseBuilder(ctx, TavrDatabase::class.java, "tavr.db").build()

    @Provides fun flightDao(db: TavrDatabase) = db.flights()
    @Provides fun poiDao(db: TavrDatabase) = db.pois()
    @Provides fun trackDao(db: TavrDatabase) = db.track()
    @Provides fun kpDao(db: TavrDatabase) = db.kp()
}
