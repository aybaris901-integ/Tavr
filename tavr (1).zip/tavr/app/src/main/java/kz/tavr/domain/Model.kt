package kz.tavr.domain

import androidx.annotation.StringRes
import kz.tavr.R

enum class PoiType(@StringRes val label: Int) {
    MOUNTAIN(R.string.type_mountain),
    VOLCANO(R.string.type_volcano),
    LAKE(R.string.type_lake),
    GLACIER(R.string.type_glacier),
    ISLAND(R.string.type_island),
    CITY(R.string.type_city),
    CANYON(R.string.type_canyon);

    companion object {
        /** Классы Wikidata (P31), которые нас интересуют. */
        val wikidataClasses: Map<String, PoiType> = mapOf(
            "Q8502" to MOUNTAIN,     // гора
            "Q207326" to MOUNTAIN,   // вершина
            "Q46831" to MOUNTAIN,    // горный хребет
            "Q8072" to VOLCANO,      // вулкан
            "Q169358" to VOLCANO,    // стратовулкан
            "Q23397" to LAKE,        // озеро
            "Q131681" to LAKE,       // водохранилище
            "Q35666" to GLACIER,     // ледник
            "Q23442" to ISLAND,      // остров
            "Q515" to CITY,          // город
            "Q1549591" to CITY,      // крупный город
            "Q1637706" to CITY,      // город-миллионник
            "Q200250" to CITY,       // мегаполис
            "Q150784" to CANYON,     // каньон
        )
    }
}

/** Откуда взято название. */
enum class NameSource { KK, RU, TRANSLIT, ID }

/** Откуда взято описание. */
enum class DescSource { KK_WIKI, LLM, RAW_RU, RAW_EN, NONE }

enum class RouteSource { AERODATABOX, MANUAL }

enum class FlightStatus { PREPARING, READY, FAILED, FLYING, DONE }
