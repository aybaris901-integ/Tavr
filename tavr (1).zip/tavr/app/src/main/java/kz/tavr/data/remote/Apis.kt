package kz.tavr.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Url

// ---------- AeroDataBox (RapidAPI) ----------

interface AeroDataBoxApi {
    /** Рейс по номеру и дате вылета (местной). */
    @GET("flights/number/{number}/{date}")
    suspend fun flight(
        @Path("number") number: String,
        @Path("date") date: String,
        @Header("X-RapidAPI-Key") key: String,
        @Header("X-RapidAPI-Host") host: String = "aerodatabox.p.rapidapi.com",
        @Query("withAircraftImage") withAircraftImage: Boolean = false,
        @Query("withLocation") withLocation: Boolean = false,
    ): List<AdbFlight>
}

@Serializable
data class AdbFlight(
    val number: String? = null,
    val departure: AdbMovement? = null,
    val arrival: AdbMovement? = null,
)

@Serializable
data class AdbMovement(
    val airport: AdbAirport? = null,
    val scheduledTime: AdbTime? = null,
)

@Serializable
data class AdbAirport(
    val icao: String? = null,
    val iata: String? = null,
    val name: String? = null,
    val municipalityName: String? = null,
    val location: AdbLocation? = null,
)

@Serializable
data class AdbLocation(val lat: Double, val lon: Double)

/** Время вида "2026-11-05 03:40Z". */
@Serializable
data class AdbTime(val utc: String? = null, val local: String? = null)

// ---------- Wikidata Query Service ----------

interface WikidataApi {
    @GET("sparql")
    suspend fun sparql(
        @Query("query") query: String,
        @Query("format") format: String = "json",
    ): JsonObject
}

// ---------- Wikipedia REST ----------

interface WikipediaApi {
    /** Полный URL: https://{lang}.wikipedia.org/api/rest_v1/page/summary/{title} */
    @GET
    suspend fun summary(@Url url: String): WikiSummary
}

@Serializable
data class WikiSummary(
    val title: String? = null,
    val extract: String? = null,
    val lang: String? = null,
)

// ---------- Wikimedia Commons ----------

interface CommonsApi {
    @GET("w/api.php")
    suspend fun imageInfo(
        @Query("titles") titles: String,
        @Query("action") action: String = "query",
        @Query("prop") prop: String = "imageinfo",
        @Query("iiprop") iiprop: String = "url|extmetadata",
        @Query("iiurlwidth") width: Int = 960,
        @Query("iiextmetadatafilter") filter: String = "Artist|LicenseShortName|Credit",
        @Query("format") format: String = "json",
        @Query("formatversion") formatVersion: Int = 2,
    ): JsonObject
}

// ---------- NOAA SWPC ----------

interface NoaaApi {
    /** Прогноз планетарного Kp-индекса на 3 суток (3-часовые интервалы). */
    @GET("products/noaa-planetary-k-index-forecast.json")
    suspend fun kpForecast(): JsonElement
}

// ---------- OpenRouter (OpenAI-совместимый Chat Completions) ----------

interface OpenRouterApi {
    @POST("chat/completions")
    suspend fun complete(
        @Header("Authorization") bearer: String,
        @Body body: ChatRequest,
        @Header("X-Title") title: String = "Tavr",
    ): ChatResponse
}

@Serializable
data class ChatRequest(
    val model: String,
    val messages: List<ChatMessage>,
    val temperature: Double = 0.5,
    @SerialName("max_tokens") val maxTokens: Int = 400,
)

@Serializable
data class ChatMessage(val role: String, val content: String)

@Serializable
data class ChatResponse(val choices: List<ChatChoice> = emptyList())

@Serializable
data class ChatChoice(val message: ChatMessage? = null)
