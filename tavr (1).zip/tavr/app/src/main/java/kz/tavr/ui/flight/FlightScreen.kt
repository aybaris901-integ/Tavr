package kz.tavr.ui.flight

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.outlined.Flight
import androidx.compose.material.icons.outlined.NightsStay
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kz.tavr.R
import kz.tavr.data.local.FlightEntity
import kz.tavr.domain.FlightStatus
import kz.tavr.geo.SeatSide
import kz.tavr.service.FlightLive
import kz.tavr.ui.components.MountainHeader
import kz.tavr.work.PrepStep
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

@Composable
fun FlightScreen(vm: FlightViewModel = hiltViewModel()) {
    val form by vm.form.collectAsStateWithLifecycle()
    val flight by vm.flight.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val live by vm.live.collectAsStateWithLifecycle()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        MountainHeader()
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            val current = flight
            if (current == null || form.editing) {
                FlightFormSection(form, vm, canCancel = current != null)
            } else {
                FlightCard(current, progress, live, vm)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FlightFormSection(form: FlightForm, vm: FlightViewModel, canCancel: Boolean) {
    var showPicker by rememberSaveable { mutableStateOf(false) }
    val locale = LocalConfiguration.current.locales[0]

    Text(stringResource(R.string.flight_greeting), style = MaterialTheme.typography.titleLarge)

    OutlinedTextField(
        value = form.number,
        onValueChange = { v -> vm.edit { it.copy(number = v.uppercase().take(10)) } },
        label = { Text(stringResource(R.string.flight_number_label)) },
        placeholder = { Text(stringResource(R.string.flight_number_hint)) },
        leadingIcon = { Icon(Icons.Outlined.Flight, null) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
        modifier = Modifier.fillMaxWidth(),
    )

    OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Outlined.CalendarMonth, null)
        Spacer(Modifier.width(8.dp))
        Text(
            stringResource(R.string.flight_date_label) + ": " +
                form.date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(locale)),
        )
    }

    Text(stringResource(R.string.seat_label), style = MaterialTheme.typography.titleMedium)
    Column {
        SeatSide.entries.forEach { seat ->
            val label = when (seat) {
                SeatSide.LEFT -> R.string.seat_left
                SeatSide.RIGHT -> R.string.seat_right
                SeatSide.BOTH -> R.string.seat_both
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .selectable(selected = form.seat == seat, role = Role.RadioButton) { vm.edit { it.copy(seat = seat) } }
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = form.seat == seat, onClick = null)
                Spacer(Modifier.width(12.dp))
                Text(stringResource(label))
            }
        }
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(R.string.airports_manual), Modifier.weight(1f))
        Switch(checked = form.manualAirports, onCheckedChange = { on -> vm.edit { it.copy(manualAirports = on) } })
    }
    if (form.manualAirports) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = form.dep,
                onValueChange = { v -> vm.edit { it.copy(dep = v.uppercase().take(3)) } },
                label = { Text(stringResource(R.string.dep_iata)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                modifier = Modifier.weight(1f),
            )
            OutlinedTextField(
                value = form.arr,
                onValueChange = { v -> vm.edit { it.copy(arr = v.uppercase().take(3)) } },
                label = { Text(stringResource(R.string.arr_iata)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                modifier = Modifier.weight(1f),
            )
        }
    }

    form.error?.let { err ->
        Text(
            if (err.arg != null) stringResource(err.message, err.arg) else stringResource(err.message),
            color = MaterialTheme.colorScheme.error,
        )
    }

    Button(
        onClick = vm::prepare,
        enabled = !form.busy,
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
        shape = RoundedCornerShape(16.dp),
    ) {
        if (form.busy) {
            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
        } else {
            Text(stringResource(R.string.btn_prepare))
        }
    }
    Text(stringResource(R.string.prepare_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    if (canCancel) {
        TextButton(onClick = vm::cancelNewFlight) { Text(stringResource(android.R.string.cancel)) }
    }

    if (showPicker) {
        val state = rememberDatePickerState(
            initialSelectedDateMillis = form.date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
        )
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { ms ->
                        vm.edit { it.copy(date = Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate()) }
                    }
                    showPicker = false
                }) { Text(stringResource(android.R.string.ok)) }
            },
        ) { DatePicker(state) }
    }
}

@Composable
private fun FlightCard(flight: FlightEntity, progress: PrepProgress, live: FlightLive?, vm: FlightViewModel) {
    val context = LocalContext.current
    var permissionDenied by remember { mutableStateOf(false) }
    val permissions = buildList {
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            permissionDenied = false
            vm.startFlightMode(context)
        } else {
            permissionDenied = true
        }
    }

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                stringResource(R.string.flight_card_title) + " · ${flight.number} · ${flight.date}",
                style = MaterialTheme.typography.labelLarge,
            )
            Text(
                stringResource(R.string.route_summary, flight.depCode, flight.arrCode, flight.distanceKm.toInt()),
                style = MaterialTheme.typography.headlineMedium,
            )
            Text("${flight.depName} → ${flight.arrName}", style = MaterialTheme.typography.bodyMedium)
            Text(
                stringResource(
                    when (flight.seat) {
                        SeatSide.LEFT -> R.string.seat_left
                        SeatSide.RIGHT -> R.string.seat_right
                        SeatSide.BOTH -> R.string.seat_both
                    },
                ),
                style = MaterialTheme.typography.bodyMedium,
            )
            Text(
                stringResource(R.string.route_great_circle_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f),
            )
        }
    }

    when (flight.status) {
        FlightStatus.PREPARING -> PrepareSteps(progress)

        FlightStatus.FAILED -> {
            Text(stringResource(R.string.prepare_failed, flight.error.orEmpty()), color = MaterialTheme.colorScheme.error)
            Button(onClick = vm::retryPrepare) { Text(stringResource(R.string.btn_retry)) }
        }

        FlightStatus.READY, FlightStatus.DONE -> {
            Text(stringResource(R.string.prepare_done, flight.poiCount), style = MaterialTheme.typography.titleMedium)
            if (!flight.tilesReady || progress.tilesSkipped) {
                Hint(Icons.Outlined.WarningAmber, stringResource(R.string.tiles_skipped))
            }
            Hint(Icons.Outlined.Flight, stringResource(R.string.gps_hint))
            Button(
                onClick = { launcher.launch(permissions) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondary,
                    contentColor = MaterialTheme.colorScheme.onSecondary,
                ),
            ) { Text(stringResource(R.string.btn_start_flight)) }
            if (permissionDenied) {
                Text(stringResource(R.string.perm_location_title), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.perm_location_text), style = MaterialTheme.typography.bodySmall)
                Text(stringResource(R.string.perm_notif_text), style = MaterialTheme.typography.bodySmall)
                Text(stringResource(R.string.perm_denied), color = MaterialTheme.colorScheme.error)
                OutlinedButton(onClick = { launcher.launch(permissions) }) { Text(stringResource(R.string.btn_grant)) }
            }
        }

        FlightStatus.FLYING -> {
            LiveStatus(live)
            OutlinedButton(onClick = { vm.stopFlightMode(context) }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.btn_stop_flight))
            }
        }
    }

    TextButton(onClick = vm::newFlight) { Text(stringResource(R.string.btn_new_flight)) }
}

@Composable
private fun PrepareSteps(progress: PrepProgress) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(stringResource(R.string.prepare_running), style = MaterialTheme.typography.titleMedium)
        PrepStep.entries.forEach { step ->
            val done = step == PrepStep.ROUTE || step.ordinal < progress.step.ordinal
            val active = step == progress.step && !done
            Row(verticalAlignment = Alignment.CenterVertically) {
                when {
                    done -> Icon(Icons.Filled.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                    active -> CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    else -> Icon(Icons.Outlined.Circle, null, tint = MaterialTheme.colorScheme.outline)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(stringResource(step.label))
                    if (active) {
                        LinearProgressIndicator(
                            progress = { progress.percent / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                        )
                    }
                }
            }
        }
        Text(stringResource(R.string.prepare_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LiveStatus(live: FlightLive?) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(stringResource(R.string.flight_mode_title), style = MaterialTheme.typography.titleMedium)
            val fix = live?.fix
            if (live == null || fix == null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.gps_searching))
                }
                Text(stringResource(R.string.gps_hint), style = MaterialTheme.typography.bodySmall)
            } else {
                Text(
                    stringResource(
                        R.string.flight_status,
                        (live.motion?.speedKmh ?: fix.speedKmh ?: 0.0).toInt(),
                        (fix.altitudeM ?: 0.0).toInt(),
                    ),
                    style = MaterialTheme.typography.titleLarge,
                )
                if (live.estimated) Hint(Icons.Outlined.WarningAmber, stringResource(R.string.position_estimated))
                if (live.night) Hint(Icons.Outlined.NightsStay, stringResource(R.string.night_quiet))
                if (live.nextPoiName != null && live.nextPoiKm != null) {
                    Text(stringResource(R.string.next_poi, live.nextPoiName, live.nextPoiKm))
                }
            }
        }
    }
}

@Composable
private fun Hint(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(icon, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
