package kz.tavr.geo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import kotlin.math.abs

class GeoMathTest {
    private val almaty = LatLon(43.2389, 76.8897)
    private val astana = LatLon(51.1694, 71.4491)

    @Test fun distance_almaty_astana() {
        assertEquals(971.0, GeoMath.distanceKm(almaty, astana), 15.0)
    }

    @Test fun bearing_along_equator_is_east() {
        assertEquals(90.0, GeoMath.initialBearing(LatLon(0.0, 0.0), LatLon(0.0, 10.0)), 1e-6)
    }

    @Test fun destination_roundtrip() {
        val p = GeoMath.destination(almaty, 330.0, 500.0)
        assertEquals(500.0, GeoMath.distanceKm(almaty, p), 0.01)
        assertEquals(330.0, GeoMath.initialBearing(almaty, p), 0.01)
    }

    @Test fun great_circle_has_endpoints_and_step() {
        val gc = GeoMath.greatCircle(almaty, astana, 50.0)
        assertEquals(almaty.lat, gc.first().lat, 1e-9)
        assertEquals(astana.lat, gc.last().lat, 1e-6)
        assertTrue(gc.zipWithNext().all { (a, b) -> GeoMath.distanceKm(a, b) <= 50.0 + 1e-6 })
    }

    @Test fun cross_track_sign_left_is_negative() {
        val start = LatLon(0.0, 0.0)
        val north = LatLon(1.0, 10.0) // курс на восток, точка севернее → слева
        assertTrue(GeoMath.crossTrackKm(start, 90.0, north) < -100)
        assertTrue(GeoMath.crossTrackKm(start, 90.0, LatLon(-1.0, 10.0)) > 100)
        assertEquals(1112.0, GeoMath.alongTrackKm(start, 90.0, north), 5.0)
        assertTrue(GeoMath.alongTrackKm(start, 90.0, LatLon(0.5, -3.0)) < 0)
    }

    @Test fun project_on_route() {
        val route = GeoMath.greatCircle(LatLon(0.0, 0.0), LatLon(0.0, 20.0), 100.0)
        val p = GeoMath.projectOnRoute(route, LatLon(-0.5, 10.0))
        assertEquals(1112.0, p.alongKm, 5.0)
        assertEquals(55.6, p.crossKm, 1.0) // южнее при курсе на восток → справа
    }

    @Test fun sample_along_spacing() {
        val route = GeoMath.greatCircle(almaty, astana, 25.0)
        val s = GeoMath.sampleAlong(route, 150.0)
        assertTrue(s.size in 7..9)
        assertTrue(s.zipWithNext().all { (a, b) -> GeoMath.distanceKm(a, b) <= 151.0 })
    }

    @Test fun corridor_is_closed_and_wide() {
        val c = GeoMath.corridor(GeoMath.greatCircle(almaty, astana, 100.0), 150.0)
        assertEquals(c.first(), c.last())
        val mid = GeoMath.interpolate(almaty, astana, 0.5)
        val nearest = c.minOf { GeoMath.distanceKm(it, mid) }
        assertEquals(150.0, nearest, 10.0)
    }
}

class ClockDirectionTest {
    @Test fun clock_hours() {
        assertEquals(12, ClockDirection.clockHour(0.0))
        assertEquals(12, ClockDirection.clockHour(359.0))
        assertEquals(3, ClockDirection.clockHour(90.0))
        assertEquals(9, ClockDirection.clockHour(270.0))
        assertEquals(1, ClockDirection.clockHour(44.0))
        assertEquals(2, ClockDirection.clockHour(46.0))
        assertEquals(6, ClockDirection.clockHour(180.0))
    }

    @Test fun side_and_minutes() {
        val pos = LatLon(0.0, 0.0)
        val poi = GeoMath.destination(GeoMath.destination(pos, 90.0, 40.0), 180.0, 50.0)
        val s = ClockDirection.sighting(pos, 90.0, 900.0, poi)
        assertEquals(Side.RIGHT, s.side)
        assertEquals(2.67, s.minutesToClosest!!, 0.05)
        assertEquals(50.0, s.closestKm, 0.5)
        assertEquals(2, s.clock) // 40 км вперёд, 50 км вправо → ~51° → сағат 2
    }

    @Test fun below_when_on_track() {
        val pos = LatLon(10.0, 10.0)
        val poi = GeoMath.destination(pos, 45.0, 60.0)
        assertEquals(Side.BELOW, ClockDirection.sighting(pos, 45.0, 850.0, poi).side)
    }
}

class SolarPositionTest {
    private fun t(iso: String) = Instant.parse(iso).toEpochMilli()

    @Test fun almaty_summer_noon() {
        // Солнечный полдень в Алматы ≈ 06:54 UTC
        val e = SolarPosition.elevationDeg(43.2389, 76.8897, t("2026-06-21T06:54:00Z"))
        assertEquals(70.2, e, 0.6)
    }

    @Test fun almaty_midnight_is_night() {
        assertTrue(SolarPosition.isNight(43.2389, 76.8897, t("2026-06-21T18:54:00Z")))
    }

    @Test fun greenwich_equinox() {
        val e = SolarPosition.elevationDeg(51.4769, 0.0, t("2026-03-20T12:07:00Z"))
        assertEquals(38.5, e, 0.6)
    }

    @Test fun sunrise_is_near_zero() {
        // Восход в Астане 21 июня ≈ 03:52 по Астане (UTC+5) = 22:52 UTC накануне
        val e = SolarPosition.elevationDeg(51.1694, 71.4491, t("2026-06-20T22:52:00Z"))
        assertTrue("elevation=$e", abs(e - (-0.833)) < 1.5)
    }
}

class TransliteratorTest {
    @Test fun kk_to_latin() {
        assertEquals("Almaty", Transliterator.kkCyrillicToLatin("Алматы"))
        assertEquals("Qazaqstan", Transliterator.kkCyrillicToLatin("Қазақстан"))
        assertEquals("Şymkent", Transliterator.kkCyrillicToLatin("Шымкент"))
        assertEquals("Ile Alatauy", Transliterator.kkCyrillicToLatin("Іле Алатауы"))
        assertEquals("Bauyrym, terezege qara!", Transliterator.kkCyrillicToLatin("Бауырым, терезеге қара!"))
    }

    @Test fun latin_to_kk() {
        assertEquals("Эверест", Transliterator.latinToKkCyrillic("Everest"))
        assertEquals("Килиманджаро", Transliterator.latinToKkCyrillic("Kilimanjaro"))
        assertEquals("Хоккайдо", Transliterator.latinToKkCyrillic("Hokkaido"))
        assertEquals("Дубай", Transliterator.latinToKkCyrillic("Dubai"))
    }
}

class CourseAndAlertTest {
    private val noonUtc = Instant.parse("2026-06-21T06:00:00Z").toEpochMilli()

    private fun track(speedKmh: Double, course: Double, n: Int): List<Fix> {
        var p = LatLon(45.0, 70.0)
        return (0 until n).map { i ->
            val f = Fix(noonUtc + i * 30_000L, p.lat, p.lon)
            p = GeoMath.destination(p, course, speedKmh * 30.0 / 3600.0)
            f
        }
    }

    @Test fun course_from_track() {
        val m = CourseEstimator.estimate(track(880.0, 300.0, 6))!!
        assertEquals(300.0, m.courseDeg, 0.5)
        assertEquals(880.0, m.speedKmh, 5.0)
    }

    @Test fun single_fix_without_gps_course_is_null() {
        assertNull(CourseEstimator.estimate(track(880.0, 300.0, 1)))
    }

    @Test fun alert_in_window_on_right() {
        val fix = Fix(noonUtc, 45.0, 70.0)
        val motion = Motion(90.0, 900.0)
        val poi = GeoMath.destination(GeoMath.destination(fix.latLon, 90.0, 40.0), 180.0, 60.0)
        val far = GeoMath.destination(fix.latLon, 90.0, 300.0)
        val policy = AlertPolicy()
        val targets = listOf(PoiTarget("near", poi), PoiTarget("far", far))
        val both = policy.poiAlerts(fix, motion, SeatSide.BOTH, targets)
        assertEquals(listOf("near"), both.map { it.poiId })
        assertEquals(Side.RIGHT, both.first().sighting.side)
        assertTrue(policy.poiAlerts(fix, motion, SeatSide.LEFT, targets).isEmpty())
        assertEquals(1, policy.poiAlerts(fix, motion, SeatSide.RIGHT, targets).size)
    }

    @Test fun no_poi_alerts_at_night() {
        val night = Fix(Instant.parse("2026-06-21T19:00:00Z").toEpochMilli(), 45.0, 70.0)
        val poi = GeoMath.destination(night.latLon, 90.0, 30.0)
        assertTrue(AlertPolicy().poiAlerts(night, Motion(90.0, 900.0), SeatSide.BOTH, listOf(PoiTarget("x", poi))).isEmpty())
    }

    @Test fun aurora_rules() {
        val winterNight = Instant.parse("2026-12-15T20:00:00Z").toEpochMilli()
        val north = Fix(winterNight, 62.0, 40.0)
        val policy = AlertPolicy()
        val a = policy.auroraAlert(north, Motion(90.0, 900.0), 5.0, SeatSide.BOTH)!!
        assertEquals(Side.LEFT, a.side) // летим на восток → север слева
        assertEquals(9, a.clock)
        assertNull(policy.auroraAlert(north, Motion(90.0, 900.0), 3.0, SeatSide.BOTH))
        assertNull(policy.auroraAlert(north.copy(lat = 50.0), Motion(90.0, 900.0), 6.0, SeatSide.BOTH))
        assertNull(policy.auroraAlert(north, Motion(90.0, 900.0), 5.0, SeatSide.RIGHT))
    }
}
