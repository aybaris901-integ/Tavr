package kz.tavr.geo

enum class SeatSide { LEFT, RIGHT, BOTH }

data class PoiTarget(val id: String, val position: LatLon)

data class PoiAlert(val poiId: String, val sighting: Sighting)

data class AuroraAlert(val kp: Double, val clock: Int, val side: Side)

/**
 * Решает, о каких объектах сказать пассажиру прямо сейчас.
 * Чистая логика без Android — покрыта JVM-тестами.
 */
class AlertPolicy(
    /** Уведомлять, только если объект пройдёт ближе этого, км. */
    private val radiusKm: Double = 150.0,
    /** Предупреждаем за столько минут до максимального сближения. */
    private val leadMaxMinutes: Double = 3.0,
    /** Не раньше этого: даже при запоздавшей точке GPS успеем сказать. */
    private val leadMinMinutes: Double = 0.0,
    /** Минимум Kp для северного сияния. */
    private val auroraMinKp: Double = 4.0,
    /** Минимальная широта для северного сияния. */
    private val auroraMinLat: Double = 55.0,
) {

    fun isNight(fix: Fix): Boolean = SolarPosition.isNight(fix.lat, fix.lon, fix.timeMillis)

    fun poiAlerts(
        fix: Fix,
        motion: Motion,
        seat: SeatSide,
        candidates: List<PoiTarget>,
    ): List<PoiAlert> {
        if (isNight(fix)) return emptyList() // ночью не беспокоим
        return candidates.mapNotNull { poi ->
            val s = ClockDirection.sighting(fix.latLon, motion.courseDeg, motion.speedKmh, poi.position)
            val minutes = s.minutesToClosest ?: return@mapNotNull null
            val inWindow = minutes in leadMinMinutes..leadMaxMinutes
            val closeEnough = s.closestKm <= radiusKm
            if (inWindow && closeEnough && seat.canSee(s.side)) PoiAlert(poi.id, s) else null
        }.sortedBy { it.sighting.minutesToClosest }
    }

    /** Северное сияние: ночь, Kp ≥ 4, широта > 55°. Смотреть надо на север. */
    fun auroraAlert(fix: Fix, motion: Motion?, kp: Double?, seat: SeatSide): AuroraAlert? {
        if (kp == null || kp < auroraMinKp) return null
        if (fix.lat <= auroraMinLat) return null
        if (!isNight(fix)) return null
        val course = motion?.courseDeg ?: return AuroraAlert(kp, 12, Side.BELOW)
        val rel = GeoMath.relativeBearing(course, 0.0)
        val side = when {
            rel in 20.0..160.0 -> Side.RIGHT
            rel in 200.0..340.0 -> Side.LEFT
            else -> Side.BELOW // север прямо по курсу или позади — видно с обеих сторон
        }
        if (!seat.canSee(side)) return null
        return AuroraAlert(kp, ClockDirection.clockHour(rel), side)
    }

    private fun SeatSide.canSee(side: Side): Boolean = when (this) {
        SeatSide.BOTH -> true
        SeatSide.LEFT -> side != Side.RIGHT
        SeatSide.RIGHT -> side != Side.LEFT
    }
}
