package kz.tavr.geo

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class LatLon(val lat: Double, val lon: Double)

/** Положение точки относительно маршрута (полилинии). */
data class RouteProjection(
    /** Расстояние вдоль маршрута от старта до проекции точки, км. */
    val alongKm: Double,
    /** Расстояние от маршрута: > 0 — справа по ходу, < 0 — слева, км. */
    val crossKm: Double,
)

/**
 * Сферическая геометрия (сфера R = 6371 км).
 * Формулы: https://www.movable-type.co.uk/scripts/latlong.html
 */
object GeoMath {
    const val EARTH_RADIUS_KM = 6371.0088

    fun Double.toRad() = this * PI / 180.0
    fun Double.toDeg() = this * 180.0 / PI

    fun normalizeDeg(deg: Double): Double {
        val d = deg % 360.0
        return if (d < 0) d + 360.0 else d
    }

    /** Нормализует долготу в диапазон [-180, 180). */
    fun normalizeLon(lon: Double): Double = ((lon + 540.0) % 360.0) - 180.0

    fun distanceKm(a: LatLon, b: LatLon): Double {
        val dLat = (b.lat - a.lat).toRad()
        val dLon = (b.lon - a.lon).toRad()
        val h = sin(dLat / 2).let { it * it } +
            cos(a.lat.toRad()) * cos(b.lat.toRad()) * sin(dLon / 2).let { it * it }
        return 2 * EARTH_RADIUS_KM * asin(sqrt(h.coerceIn(0.0, 1.0)))
    }

    /** Начальный пеленг из a в b, градусы [0, 360). */
    fun initialBearing(a: LatLon, b: LatLon): Double {
        val φ1 = a.lat.toRad()
        val φ2 = b.lat.toRad()
        val Δλ = (b.lon - a.lon).toRad()
        val y = sin(Δλ) * cos(φ2)
        val x = cos(φ1) * sin(φ2) - sin(φ1) * cos(φ2) * cos(Δλ)
        return normalizeDeg(atan2(y, x).toDeg())
    }

    /** Точка на расстоянии [distanceKm] от [start] по пеленгу [bearingDeg]. */
    fun destination(start: LatLon, bearingDeg: Double, distanceKm: Double): LatLon {
        val δ = distanceKm / EARTH_RADIUS_KM
        val θ = bearingDeg.toRad()
        val φ1 = start.lat.toRad()
        val λ1 = start.lon.toRad()
        val φ2 = asin(sin(φ1) * cos(δ) + cos(φ1) * sin(δ) * cos(θ))
        val λ2 = λ1 + atan2(sin(θ) * sin(δ) * cos(φ1), cos(δ) - sin(φ1) * sin(φ2))
        return LatLon(φ2.toDeg(), normalizeLon(λ2.toDeg()))
    }

    /** Промежуточная точка на дуге большого круга, fraction ∈ [0, 1]. */
    fun interpolate(a: LatLon, b: LatLon, fraction: Double): LatLon {
        val δ = distanceKm(a, b) / EARTH_RADIUS_KM
        if (δ < 1e-12) return a
        val φ1 = a.lat.toRad(); val λ1 = a.lon.toRad()
        val φ2 = b.lat.toRad(); val λ2 = b.lon.toRad()
        val A = sin((1 - fraction) * δ) / sin(δ)
        val B = sin(fraction * δ) / sin(δ)
        val x = A * cos(φ1) * cos(λ1) + B * cos(φ2) * cos(λ2)
        val y = A * cos(φ1) * sin(λ1) + B * cos(φ2) * sin(λ2)
        val z = A * sin(φ1) + B * sin(φ2)
        return LatLon(atan2(z, sqrt(x * x + y * y)).toDeg(), atan2(y, x).toDeg())
    }

    /** Дуга большого круга, разбитая на отрезки не длиннее [stepKm]. Включает обе концевые точки. */
    fun greatCircle(a: LatLon, b: LatLon, stepKm: Double = 50.0): List<LatLon> {
        val total = distanceKm(a, b)
        val n = ceil(total / stepKm).toInt().coerceAtLeast(1)
        return (0..n).map { interpolate(a, b, it.toDouble() / n) }
    }

    /**
     * Расстояние от точки до большого круга, проходящего через [start] с курсом [bearingDeg].
     * Положительное — точка справа по ходу.
     */
    fun crossTrackKm(start: LatLon, bearingDeg: Double, point: LatLon): Double {
        val δ13 = distanceKm(start, point) / EARTH_RADIUS_KM
        val θ13 = initialBearing(start, point).toRad()
        val θ12 = bearingDeg.toRad()
        return asin((sin(δ13) * sin(θ13 - θ12)).coerceIn(-1.0, 1.0)) * EARTH_RADIUS_KM
    }

    /**
     * Расстояние вдоль курса от [start] до проекции точки. Отрицательное — точка уже позади.
     */
    fun alongTrackKm(start: LatLon, bearingDeg: Double, point: LatLon): Double {
        val δ13 = distanceKm(start, point) / EARTH_RADIUS_KM
        val θ13 = initialBearing(start, point).toRad()
        val θ12 = bearingDeg.toRad()
        val δxt = asin((sin(δ13) * sin(θ13 - θ12)).coerceIn(-1.0, 1.0))
        val cosXt = cos(δxt)
        if (abs(cosXt) < 1e-12) return 0.0
        val δat = acos((cos(δ13) / cosXt).coerceIn(-1.0, 1.0))
        val sign = if (cos(θ13 - θ12) < 0) -1.0 else 1.0
        return sign * δat * EARTH_RADIUS_KM
    }

    /** Пеленг цели относительно носа самолёта, [0, 360): 0 — прямо, 90 — справа. */
    fun relativeBearing(courseDeg: Double, bearingToTargetDeg: Double): Double =
        normalizeDeg(bearingToTargetDeg - courseDeg)

    fun lengthKm(route: List<LatLon>): Double =
        route.zipWithNext().sumOf { (a, b) -> distanceKm(a, b) }

    /** Проекция точки на полилинию маршрута. */
    fun projectOnRoute(route: List<LatLon>, p: LatLon): RouteProjection {
        require(route.isNotEmpty())
        if (route.size == 1) return RouteProjection(0.0, distanceKm(route[0], p))
        var best = RouteProjection(0.0, Double.MAX_VALUE)
        var cumulative = 0.0
        for ((a, b) in route.zipWithNext()) {
            val segLen = distanceKm(a, b)
            val brg = initialBearing(a, b)
            val along = alongTrackKm(a, brg, p)
            val candidate = when {
                along < 0 -> RouteProjection(cumulative, signedDistance(a, brg, p))
                along > segLen -> RouteProjection(cumulative + segLen, signedDistance(b, brg, p))
                else -> RouteProjection(cumulative + along, crossTrackKm(a, brg, p))
            }
            if (abs(candidate.crossKm) < abs(best.crossKm)) best = candidate
            cumulative += segLen
        }
        return best
    }

    private fun signedDistance(from: LatLon, brg: Double, p: LatLon): Double {
        val d = distanceKm(from, p)
        return if (crossTrackKm(from, brg, p) < 0) -d else d
    }

    /** Точки, равномерно расставленные вдоль маршрута с шагом [stepKm] (для запросов к Wikidata). */
    fun sampleAlong(route: List<LatLon>, stepKm: Double): List<LatLon> {
        if (route.size < 2) return route
        val result = mutableListOf(route.first())
        var carry = 0.0
        for ((a, b) in route.zipWithNext()) {
            val seg = distanceKm(a, b)
            var pos = stepKm - carry
            while (pos <= seg) {
                result += interpolate(a, b, pos / seg)
                pos += stepKm
            }
            carry = (carry + seg) % stepKm
        }
        if (distanceKm(result.last(), route.last()) > stepKm * 0.3) result += route.last()
        return result
    }

    /**
     * Полигон-коридор шириной [halfWidthKm] по обе стороны маршрута
     * (для офлайн-региона карты). Обход: левая сторона вперёд, правая назад.
     */
    fun corridor(route: List<LatLon>, halfWidthKm: Double): List<LatLon> {
        require(route.size >= 2)
        val left = mutableListOf<LatLon>()
        val right = mutableListOf<LatLon>()
        route.forEachIndexed { i, p ->
            val brg = when (i) {
                0 -> initialBearing(p, route[1])
                route.lastIndex -> normalizeDeg(initialBearing(p, route[i - 1]) + 180)
                else -> initialBearing(p, route[i + 1])
            }
            left += destination(p, brg - 90, halfWidthKm)
            right += destination(p, brg + 90, halfWidthKm)
        }
        val start = route.first()
        val end = route.last()
        val startCap = destination(start, initialBearing(start, route[1]) + 180, halfWidthKm)
        val endCap = destination(end, initialBearing(end, route[route.lastIndex - 1]) + 180, halfWidthKm)
        return buildList {
            add(startCap); addAll(left); add(endCap); addAll(right.reversed()); add(startCap)
        }
    }
}
