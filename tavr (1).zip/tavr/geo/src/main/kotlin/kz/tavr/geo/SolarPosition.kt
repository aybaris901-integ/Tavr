package kz.tavr.geo

import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.tan

/**
 * Положение солнца по алгоритму NOAA (General Solar Position Calculations,
 * NOAA Global Monitoring Division; та же схема, что в NOAA Solar Calculator).
 * Точность высоты — порядка 0.1–0.5°, для «день/ночь» более чем достаточно.
 */
object SolarPosition {
    /** Солнце ниже этого — ночь (гражданские сумерки закончились). */
    const val NIGHT_ELEVATION_DEG = -6.0

    private fun rad(d: Double) = d * PI / 180.0
    private fun deg(r: Double) = r * 180.0 / PI

    /**
     * Высота солнца над горизонтом, градусы, с поправкой на атмосферную рефракцию.
     * @param epochMillis время UTC в миллисекундах.
     */
    fun elevationDeg(lat: Double, lon: Double, epochMillis: Long): Double {
        val jd = epochMillis / 86_400_000.0 + 2_440_587.5
        val t = (jd - 2_451_545.0) / 36_525.0 // юлианские столетия

        val geomMeanLong = GeoMath.normalizeDeg(280.46646 + t * (36000.76983 + t * 0.0003032))
        val geomMeanAnom = 357.52911 + t * (35999.05029 - 0.0001537 * t)
        val ecc = 0.016708634 - t * (0.000042037 + 0.0000001267 * t)
        val m = rad(geomMeanAnom)
        val eqOfCenter = sin(m) * (1.914602 - t * (0.004817 + 0.000014 * t)) +
            sin(2 * m) * (0.019993 - 0.000101 * t) + sin(3 * m) * 0.000289
        val trueLong = geomMeanLong + eqOfCenter
        val omega = 125.04 - 1934.136 * t
        val appLong = trueLong - 0.00569 - 0.00478 * sin(rad(omega))
        val meanObliq = 23.0 + (26.0 + (21.448 - t * (46.815 + t * (0.00059 - t * 0.001813))) / 60.0) / 60.0
        val obliqCorr = meanObliq + 0.00256 * cos(rad(omega))
        val declination = deg(asin(sin(rad(obliqCorr)) * sin(rad(appLong))))

        val y = tan(rad(obliqCorr / 2)).let { it * it }
        val l0 = rad(geomMeanLong)
        val eqOfTimeMin = 4 * deg(
            y * sin(2 * l0) - 2 * ecc * sin(m) + 4 * ecc * y * sin(m) * cos(2 * l0) -
                0.5 * y * y * sin(4 * l0) - 1.25 * ecc * ecc * sin(2 * m),
        )

        val minutesUtc = ((epochMillis % 86_400_000L + 86_400_000L) % 86_400_000L) / 60_000.0
        val trueSolarTime = ((minutesUtc + eqOfTimeMin + 4 * lon) % 1440 + 1440) % 1440
        val hourAngle = if (trueSolarTime / 4 < 0) trueSolarTime / 4 + 180 else trueSolarTime / 4 - 180

        val cosZenith = sin(rad(lat)) * sin(rad(declination)) +
            cos(rad(lat)) * cos(rad(declination)) * cos(rad(hourAngle))
        val zenith = deg(acos(cosZenith.coerceIn(-1.0, 1.0)))
        val elevation = 90.0 - zenith
        return elevation + refraction(elevation)
    }

    fun isNight(lat: Double, lon: Double, epochMillis: Long): Boolean =
        elevationDeg(lat, lon, epochMillis) < NIGHT_ELEVATION_DEG

    /** Поправка на рефракцию по NOAA, градусы. */
    private fun refraction(e: Double): Double {
        if (e > 85.0) return 0.0
        val te = tan(rad(e))
        val arcsec = when {
            e > 5.0 -> 58.1 / te - 0.07 / (te * te * te) + 0.000086 / (te * te * te * te * te)
            e > -0.575 -> 1735.0 + e * (-518.2 + e * (103.4 + e * (-12.79 + e * 0.711)))
            else -> -20.772 / te
        }
        return arcsec / 3600.0
    }
}
