package kz.tavr.geo

/** Одна GPS-точка. */
data class Fix(
    val timeMillis: Long,
    val lat: Double,
    val lon: Double,
    val altitudeM: Double? = null,
    /** Скорость из GPS, км/ч (если приёмник её отдал). */
    val speedKmh: Double? = null,
    /** Курс из GPS, градусы (если приёмник его отдал). */
    val bearingDeg: Double? = null,
) {
    val latLon get() = LatLon(lat, lon)
}

data class Motion(val courseDeg: Double, val speedKmh: Double)

/**
 * Курс и путевая скорость по последним точкам трека.
 * Берём самую раннюю точку в окне [windowMillis] и текущую: на интервале 1–3 мин
 * это сглаживает шум отдельных фиксов, а самолёт за это время почти не поворачивает.
 */
object CourseEstimator {
    const val DEFAULT_WINDOW_MS = 3 * 60_000L
    private const val MIN_BASE_KM = 2.0

    fun estimate(fixes: List<Fix>, windowMillis: Long = DEFAULT_WINDOW_MS): Motion? {
        if (fixes.isEmpty()) return null
        val sorted = fixes.sortedBy { it.timeMillis }
        val last = sorted.last()
        val base = sorted.firstOrNull {
            last.timeMillis - it.timeMillis <= windowMillis &&
                GeoMath.distanceKm(it.latLon, last.latLon) >= MIN_BASE_KM
        }
        if (base != null && base !== last) {
            val dist = GeoMath.distanceKm(base.latLon, last.latLon)
            val hours = (last.timeMillis - base.timeMillis) / 3_600_000.0
            if (hours > 0) {
                // Курс в текущей точке: обратный пеленг от последней точки к базе + 180°.
                val course = GeoMath.normalizeDeg(GeoMath.initialBearing(last.latLon, base.latLon) + 180.0)
                return Motion(course, dist / hours)
            }
        }
        // Одна точка — доверяем данным приёмника, если они есть.
        val b = last.bearingDeg
        val s = last.speedKmh
        return if (b != null && s != null && s > 100) Motion(b, s) else null
    }
}
