package kz.tavr.geo

/**
 * Транслитерация для названий и текстов.
 *  - kk кириллица → kk латиница (алфавит 2021 г.);
 *  - латиница (en/de/…) → kk кириллица, когда в Wikidata нет метки на kk/ru.
 */
object Transliterator {

    private val cyrToLat: Map<Char, String> = mapOf(
        'а' to "a", 'ә' to "ä", 'б' to "b", 'в' to "v", 'г' to "g", 'ғ' to "ğ",
        'д' to "d", 'е' to "e", 'ё' to "io", 'ж' to "j", 'з' to "z", 'и' to "i",
        'й' to "i", 'к' to "k", 'қ' to "q", 'л' to "l", 'м' to "m", 'н' to "n",
        'ң' to "ñ", 'о' to "o", 'ө' to "ö", 'п' to "p", 'р' to "r", 'с' to "s",
        'т' to "t", 'у' to "u", 'ұ' to "ū", 'ү' to "ü", 'ф' to "f", 'х' to "h",
        'һ' to "h", 'ц' to "ts", 'ч' to "ç", 'ш' to "ş", 'щ' to "şş", 'ъ' to "",
        'ы' to "y", 'і' to "ı", 'ь' to "", 'э' to "e", 'ю' to "iu", 'я' to "ia",
    )

    /** Казахская кириллица → латиница. Регистр сохраняется (первая буква диграфа заглавная). */
    fun kkCyrillicToLatin(text: String): String = buildString(text.length) {
        for (ch in text) {
            val lower = ch.lowercaseChar()
            val mapped = cyrToLat[lower]
            when {
                mapped == null -> append(ch)
                ch.isUpperCase() -> append(upperFirst(mapped))
                else -> append(mapped)
            }
        }
    }

    // Казахская заглавная «I» для «і» — без точки, для «и/й» — с точкой (İ).
    private fun upperFirst(s: String): String = when (s) {
        "" -> ""
        "i" -> "İ"
        "ı" -> "I"
        else -> s.substring(0, 1).uppercase() + s.substring(1)
    }

    private val latDigraphs = listOf(
        "shch" to "щ", "sch" to "ш", "tsch" to "ч",
        "sh" to "ш", "ch" to "ч", "zh" to "ж", "kh" to "х", "ts" to "ц",
        "ya" to "я", "yu" to "ю", "yo" to "ё", "ye" to "е", "ia" to "иа",
        "ph" to "ф", "th" to "т", "ck" to "к", "qu" to "кв", "oo" to "у", "ee" to "и",
        "ou" to "у", "gh" to "г",
        "ai" to "ай", "ei" to "ей", "oi" to "ой", "ui" to "уй",
    )

    private val latSingle: Map<Char, String> = mapOf(
        'a' to "а", 'b' to "б", 'c' to "к", 'd' to "д", 'e' to "е", 'f' to "ф",
        'g' to "г", 'h' to "х", 'i' to "и", 'j' to "дж", 'k' to "к", 'l' to "л",
        'm' to "м", 'n' to "н", 'o' to "о", 'p' to "п", 'q' to "қ", 'r' to "р",
        's' to "с", 't' to "т", 'u' to "у", 'v' to "в", 'w' to "у", 'x' to "кс",
        'y' to "й", 'z' to "з",
        'ä' to "ә", 'ö' to "ө", 'ü' to "ү", 'é' to "е", 'è' to "е", 'á' to "а",
        'í' to "и", 'ó' to "о", 'ú' to "у", 'ñ' to "нь", 'ç' to "ч", 'ş' to "ш",
        'ğ' to "ғ", 'ı' to "ы", 'ß' to "сс", 'å' to "о", 'ø' to "ө",
    )

    /** Приблизительная транслитерация латиницы в кириллицу для имён собственных. */
    fun latinToKkCyrillic(text: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (!ch.isLetter()) { sb.append(ch); i++; continue }
            val rest = text.substring(i).lowercase()
            val digraph = latDigraphs.firstOrNull { rest.startsWith(it.first) }
            val (cyr, len) = when {
                digraph != null -> digraph.second to digraph.first.length
                else -> (latSingle[ch.lowercaseChar()] ?: ch.toString()) to 1
            }
            // «e» в начале слова читаем как «э» (Everest → Эверест)
            val atWordStart = i == 0 || !text[i - 1].isLetter()
            val piece = if (atWordStart && cyr == "е") "э" else cyr
            sb.append(if (ch.isUpperCase()) piece.replaceFirstChar { it.uppercase() } else piece)
            i += len
        }
        return sb.toString()
    }

    fun isCyrillic(text: String): Boolean =
        text.any { Character.UnicodeBlock.of(it) == Character.UnicodeBlock.CYRILLIC }
}
