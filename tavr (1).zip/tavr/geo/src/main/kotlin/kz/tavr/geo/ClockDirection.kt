package kz.tavr.geo

import kotlin.math.abs
import kotlin.math.roundToInt

enum class Side { LEFT, RIGHT, BELOW }

/** Как POI видно из самолёта в данный момент. */
data class Sighting(
    /** Расстояние до POI сейчас, км. */
    val distanceKm: Double,
    /** Пеленг относительно носа, [0, 360). */
    val relativeBearingDeg: Double,
    /** Направление «сағат N», 1..12. */
    val clock: Int,
    /** Сторона в момент максимального сближения. */
    val side: Side,
    /** Расстояние при максимальном сближении, км. */
    val closestKm: Double,
    /** Сколько осталось лететь до сближения, км (< 0 — уже пролетели). */
    val alongKm: Double,
    /** Минут до максимального сближения (null, если неизвестна скорость). */
    val minutesToClosest: Double?,
)

object ClockDirection {
    /** Ближе этого к оси трека объект считается «төменде». */
    const val BELOW_THRESHOLD_KM = 15.0

    /** Относительный пеленг → «сағат N»: 0° = 12, 90° = 3, 270° = 9. */
    fun clockHour(relativeBearingDeg: Double): Int {
        val h = (GeoMath.normalizeDeg(relativeBearingDeg) / 30.0).roundToInt() % 12
        return if (h == 0) 12 else h
    }

    fun side(crossTrackKm: Double, belowThresholdKm: Double = BELOW_THRESHOLD_KM): Side = when {
        abs(crossTrackKm) <= belowThresholdKm -> Side.BELOW
        crossTrackKm > 0 -> Side.RIGHT
        else -> Side.LEFT
    }

    /**
     * Геометрия наблюдения POI из точки [position] при курсе [courseDeg] и путевой скорости [speedKmh].
     * Траектория считается прямой (дуга большого круга) — на горизонте в несколько минут это точно.
     */
    fun sighting(position: LatLon, courseDeg: Double, speedKmh: Double?, poi: LatLon): Sighting {
        val dist = GeoMath.distanceKm(position, poi)
        val rel = GeoMath.relativeBearing(courseDeg, GeoMath.initialBearing(position, poi))
        val cross = GeoMath.crossTrackKm(position, courseDeg, poi)
        val along = GeoMath.alongTrackKm(position, courseDeg, poi)
        val minutes = speedKmh?.takeIf { it > 1.0 }?.let { along / it * 60.0 }
        return Sighting(
            distanceKm = dist,
            relativeBearingDeg = rel,
            clock = clockHour(rel),
            side = side(cross),
            closestKm = if (along > 0) abs(cross) else dist,
            alongKm = along,
            minutesToClosest = minutes,
        )
    }
}
