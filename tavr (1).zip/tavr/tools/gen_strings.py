#!/usr/bin/env python3
"""
Единый источник строк Tavr. Генерирует:
  values/            — казахский (кириллица), язык по умолчанию
  values-kk/         — то же самое (явно для локали kk)
  values-b+kk+Latn/  — казахский латиницей (автоматически из кириллицы, алфавит 2021)
  values-ru/, values-en/
Запуск из корня проекта:  python3 tools/gen_strings.py
"""
import os
from xml.sax.saxutils import escape

# key: (kk, ru, en)
S = {
    "app_name": ("Tavr", "Tavr", "Tavr"),
    "slogan": ("Tavr — терезе сыртындағы әлем", "Tavr — мир за окном", "Tavr — the world outside your window"),

    "nav_flight": ("Рейс", "Рейс", "Flight"),
    "nav_map": ("Карта", "Карта", "Map"),
    "nav_feed": ("Таспа", "Лента", "Feed"),
    "nav_settings": ("Баптаулар", "Настройки", "Settings"),

    "flight_greeting": ("Бауырым, қай рейспен ұшасың?", "Бауырым, каким рейсом летишь?", "Bauyrym, which flight are you on?"),
    "flight_number_label": ("Рейс нөмірі", "Номер рейса", "Flight number"),
    "flight_number_hint": ("мысалы, KC 921", "например, KC 921", "e.g. KC 921"),
    "flight_date_label": ("Ұшу күні", "Дата вылета", "Date"),
    "seat_label": ("Орның қай жақта?", "Где твоё место?", "Where is your seat?"),
    "seat_left": ("Терезе сол жақта", "Окно слева", "Window on the left"),
    "seat_right": ("Терезе оң жақта", "Окно справа", "Window on the right"),
    "seat_both": ("Екі жақ та", "Обе стороны", "Both sides"),
    "airports_manual": ("Әуежайларды қолмен енгізу", "Ввести аэропорты вручную", "Enter airports manually"),
    "dep_iata": ("Ұшу әуежайы (IATA)", "Аэропорт вылета (IATA)", "From (IATA)"),
    "arr_iata": ("Қону әуежайы (IATA)", "Аэропорт прилёта (IATA)", "To (IATA)"),

    "btn_prepare": ("Ұшуға дайындалу", "Подготовиться к полёту", "Prepare for the flight"),
    "prepare_hint": ("Интернет бар кезде дайындалып ал — ұшақта бәрі офлайн жұмыс істейді.",
                     "Подготовься, пока есть интернет, — в самолёте всё работает офлайн.",
                     "Prepare while you are online — everything works offline in the air."),
    "prepare_running": ("Дайындалып жатырмыз…", "Готовимся…", "Preparing…"),
    "prepare_done": ("Дайын! Жолда %1$d қызық нысан бар.", "Готово! Интересных объектов по пути: %1$d.", "Ready! %1$d sights along the way."),
    "prepare_failed": ("Дайындық аяқталмады: %1$s", "Подготовка не удалась: %1$s", "Preparation failed: %1$s"),
    "tiles_skipped": ("Офлайн карта жүктелмеді — MapTiler кілтін баптауларда енгіз.",
                      "Офлайн-карта не скачана — добавь ключ MapTiler в настройках.",
                      "Offline map skipped — add a MapTiler key in Settings."),
    "step_route": ("Маршрут", "Маршрут", "Route"),
    "step_poi": ("Жолдағы көрікті жерлер", "Объекты по пути", "Sights along the route"),
    "step_text": ("Сипаттамалар", "Описания", "Descriptions"),
    "step_photo": ("Фотосуреттер", "Фотографии", "Photos"),
    "step_kp": ("Солтүстік шұғыла болжамы", "Прогноз северного сияния", "Aurora forecast"),
    "step_tiles": ("Офлайн карта", "Офлайн-карта", "Offline map"),

    "flight_card_title": ("Сенің рейсің", "Твой рейс", "Your flight"),
    "route_summary": ("%1$s → %2$s · %3$d км", "%1$s → %2$s · %3$d км", "%1$s → %2$s · %3$d km"),
    "route_great_circle_note": ("Маршрут әуежайлар арасындағы ең қысқа доғамен есептелді — нақты жол сәл басқаша болуы мүмкін.",
                                "Маршрут рассчитан по дуге большого круга между аэропортами — реальный путь может немного отличаться.",
                                "Route is a great circle between the airports — the real track may differ a little."),
    "btn_start_flight": ("Ұшу режимін қосу", "Включить режим полёта", "Start flight mode"),
    "btn_stop_flight": ("Ұшу режимін өшіру", "Выключить режим полёта", "Stop flight mode"),
    "btn_new_flight": ("Жаңа рейс", "Новый рейс", "New flight"),
    "btn_retry": ("Қайталау", "Повторить", "Retry"),

    "flight_mode_title": ("Ұшу режимі", "Режим полёта", "Flight mode"),
    "flight_mode_running": ("Tavr терезе сыртын бақылап отыр", "Tavr следит за видом из окна", "Tavr is watching the view"),
    "gps_hint": ("Телефонды терезеге жақын ұста — GPS сонда жақсы ұстайды.",
                 "Держи телефон ближе к окну — так GPS ловит лучше.",
                 "Keep the phone near the window — GPS works better there."),
    "gps_searching": ("GPS сигналын іздеп жатырмын…", "Ищу сигнал GPS…", "Looking for GPS…"),
    "position_estimated": ("GPS жоқ — орын кесте бойынша болжанды", "Нет GPS — позиция по расписанию", "No GPS — position estimated from schedule"),
    "flight_status": ("%1$d км/сағ · %2$d м", "%1$d км/ч · %2$d м", "%1$d km/h · %2$d m"),
    "next_poi": ("Келесі: %1$s, %2$d км", "Следующий: %1$s, %2$d км", "Next: %1$s, %2$d km"),
    "night_quiet": ("Түн — тыныш режим. Тек солтүстік шұғыла туралы айтамын.",
                    "Ночь — тихий режим. Скажу только о северном сиянии.",
                    "Night — quiet mode. I'll only tell you about auroras."),

    "side_left": ("Сол жақта", "Слева", "On the left"),
    "side_right": ("Оң жақта", "Справа", "On the right"),
    "side_below": ("Төменде", "Внизу", "Below"),
    "elevation_suffix": (" (%1$d м)", " (%1$d м)", " (%1$d m)"),

    "notif_title": ("Бауырым, терезеге қара!", "Бауырым, посмотри в окно!", "Bauyrym, look out the window!"),
    "notif_body": ("%1$s — %2$s%3$s, %4$s, %5$s", "%1$s — %2$s%3$s, %4$s, %5$s", "%1$s — %2$s%3$s, %4$s, %5$s"),
    "aurora_title": ("Бауырым, солтүстікке қара!", "Бауырым, посмотри на север!", "Bauyrym, look north!"),
    "aurora_body": ("Солтүстік шұғыла көрінуі мүмкін (Kp %1$s). %2$s, %3$s. Салон шамы сөнсе, жақсырақ көрінеді.",
                    "Возможно северное сияние (Kp %1$s). %2$s, %3$s. Если приглушить свет, будет лучше видно.",
                    "Aurora possible (Kp %1$s). %2$s, %3$s. It's easier to see with the cabin lights off."),
    "channel_alerts": ("Терезе хабарлары", "Подсказки у окна", "Window alerts"),
    "channel_service": ("Ұшу режимі", "Режим полёта", "Flight mode"),
    "channel_prepare": ("Ұшуға дайындық", "Подготовка к полёту", "Flight preparation"),

    "feed_upcoming": ("Алда", "Впереди", "Ahead"),
    "feed_seen": ("Көрілді", "Увидели", "Seen"),
    "feed_empty_upcoming": ("Әзірге бос. Алдымен ұшуға дайындал, бауырым.", "Пока пусто. Сначала подготовься к полёту, бауырым.", "Nothing yet. Prepare for your flight first, bauyrym."),
    "feed_empty_seen": ("Әлі ештеңе көрген жоқпыз. Терезеден көз алма!", "Пока ничего не видели. Не отходи от окна!", "Nothing seen yet. Keep an eye on the window!"),
    "km_ahead": ("%1$d км алда", "через %1$d км", "%1$d km ahead"),
    "elevation_m": ("%1$d м", "%1$d м", "%1$d m"),
    "population_fmt": ("%1$s тұрғын", "%1$s жителей", "%1$s people"),
    "photo_credit": ("Фото: %1$s · %2$s", "Фото: %1$s · %2$s", "Photo: %1$s · %2$s"),
    "desc_translated": ("ЖИ көмегімен аударылды", "Переведено с помощью ИИ", "Translated with AI"),
    "desc_original_lang": ("Қазақша сипаттама әлі жоқ — түпнұсқа мәтін", "Описания на казахском пока нет — исходный текст", "No Kazakh description yet — original text"),
    "desc_missing": ("Сипаттама табылмады.", "Описание не найдено.", "No description found."),

    "type_mountain": ("Тау", "Гора", "Mountain"),
    "type_volcano": ("Жанартау", "Вулкан", "Volcano"),
    "type_lake": ("Көл", "Озеро", "Lake"),
    "type_glacier": ("Мұздық", "Ледник", "Glacier"),
    "type_island": ("Арал", "Остров", "Island"),
    "type_city": ("Қала", "Город", "City"),
    "type_canyon": ("Шатқал", "Каньон", "Canyon"),

    "settings_language": ("Тіл", "Язык", "Language"),
    "settings_keys": ("API кілттері", "API-ключи", "API keys"),
    "key_openrouter": ("OpenRouter кілті", "Ключ OpenRouter", "OpenRouter key"),
    "key_model": ("LLM моделі (OpenRouter)", "Модель LLM (OpenRouter)", "LLM model (OpenRouter)"),
    "key_aerodatabox": ("AeroDataBox кілті (RapidAPI)", "Ключ AeroDataBox (RapidAPI)", "AeroDataBox key (RapidAPI)"),
    "key_maptiler": ("MapTiler кілті", "Ключ MapTiler", "MapTiler key"),
    "keys_note": ("Кілттер тек осы телефонда сақталады.", "Ключи хранятся только на этом телефоне.", "Keys are stored only on this phone."),
    "btn_save": ("Сақтау", "Сохранить", "Save"),
    "saved": ("Сақталды ✓", "Сохранено ✓", "Saved ✓"),
    "btn_test_notification": ("Хабарламаны сынау", "Проверить уведомление", "Test notification"),
    "settings_about": ("Деректер: Wikidata, Wikipedia, Wikimedia Commons, NOAA SWPC, AeroDataBox. Карта: © MapTiler © OpenStreetMap.",
                       "Данные: Wikidata, Wikipedia, Wikimedia Commons, NOAA SWPC, AeroDataBox. Карта: © MapTiler © OpenStreetMap.",
                       "Data: Wikidata, Wikipedia, Wikimedia Commons, NOAA SWPC, AeroDataBox. Map: © MapTiler © OpenStreetMap."),
    "test_poi_name": ("Хан Тәңірі", "Хан-Тенгри", "Khan Tengri"),

    "perm_location_title": ("Орынды анықтау", "Геолокация", "Location"),
    "perm_location_text": ("Ұшақтың қайда екенін білу үшін GPS керек. Ол ұшақ режимінде де, интернетсіз де жұмыс істейді.",
                           "Чтобы знать, где самолёт, нужен GPS. Он работает и в авиарежиме, без интернета.",
                           "GPS tells me where the plane is. It works in airplane mode, without internet."),
    "perm_notif_text": ("Терезеге қашан қарау керегін айту үшін хабарламаға рұқсат бер.",
                        "Разреши уведомления, чтобы я подсказывал, когда смотреть в окно.",
                        "Allow notifications so I can tell you when to look out."),
    "btn_grant": ("Рұқсат беру", "Разрешить", "Allow"),
    "perm_denied": ("Рұқсатсыз ұшу режимі жұмыс істемейді.", "Без разрешения режим полёта не работает.", "Flight mode can't work without this permission."),

    "err_flight_number": ("Рейс нөмірін енгіз.", "Введи номер рейса.", "Enter a flight number."),
    "err_flight_not_found": ("Рейс табылмады. Әуежайларды қолмен енгізіп көр.", "Рейс не найден. Попробуй ввести аэропорты вручную.", "Flight not found. Try entering the airports manually."),
    "err_network": ("Интернетке қосылу мүмкін болмады.", "Не удалось подключиться к интернету.", "Couldn't reach the internet."),
    "err_need_airports": ("Ұшу және қону әуежайларының IATA кодын енгіз (мысалы, ALA, NQZ).",
                          "Введи IATA-коды аэропортов вылета и прилёта (например, ALA, NQZ).",
                          "Enter departure and arrival IATA codes (e.g. ALA, NQZ)."),
    "err_no_aerodatabox_key": ("AeroDataBox кілті жоқ — әуежайларды қолмен енгіз.", "Нет ключа AeroDataBox — введи аэропорты вручную.", "No AeroDataBox key — enter airports manually."),
    "err_airport_not_found": ("%1$s әуежайы табылмады.", "Аэропорт %1$s не найден.", "Airport %1$s not found."),

    "map_no_key": ("MapTiler кілті жоқ — қарапайым карта.", "Нет ключа MapTiler — упрощённая карта.", "No MapTiler key — basic map."),
    "map_no_flight": ("Алдымен рейсті дайында, бауырым.", "Сначала подготовь рейс, бауырым.", "Prepare a flight first, bauyrym."),
}

# Плюралы: key -> (kk{q:..}, ru{q:..}, en{q:..})
P = {
    "clock_dir": (
        {"other": "сағат %d бағытында"},
        {"one": "на %d час", "few": "на %d часа", "many": "на %d часов", "other": "на %d часа"},
        {"one": "at %d o’clock", "other": "at %d o’clock"},
    ),
    "minutes_later": (
        {"other": "%d минуттан кейін"},
        {"one": "через %d минуту", "few": "через %d минуты", "many": "через %d минут", "other": "через %d минуты"},
        {"one": "in %d minute", "other": "in %d minutes"},
    ),
}

CYR2LAT = {
    'а': "a", 'ә': "ä", 'б': "b", 'в': "v", 'г': "g", 'ғ': "ğ", 'д': "d", 'е': "e", 'ё': "io",
    'ж': "j", 'з': "z", 'и': "i", 'й': "i", 'к': "k", 'қ': "q", 'л': "l", 'м': "m", 'н': "n",
    'ң': "ñ", 'о': "o", 'ө': "ö", 'п': "p", 'р': "r", 'с': "s", 'т': "t", 'у': "u", 'ұ': "ū",
    'ү': "ü", 'ф': "f", 'х': "h", 'һ': "h", 'ц': "ts", 'ч': "ç", 'ш': "ş", 'щ': "şş", 'ъ': "",
    'ы': "y", 'і': "ı", 'ь': "", 'э': "e", 'ю': "iu", 'я': "ia",
}


def to_latin(text: str) -> str:
    out = []
    for ch in text:
        m = CYR2LAT.get(ch.lower())
        if m is None:
            out.append(ch)
        elif ch.isupper():
            out.append({"i": "İ", "ı": "I"}.get(m, m[:1].upper() + m[1:]))
        else:
            out.append(m)
    return "".join(out)


def esc(s: str) -> str:
    s = escape(s).replace("\\", "\\\\").replace('"', '\\"').replace("'", "\\'")
    if s.startswith(" ") or s.endswith(" "):
        s = '"' + s + '"'  # иначе Android обрежет пробел
    if s.startswith(("@", "?")):
        s = "\\" + s
    return s


def write(folder: str, idx: int, latin: bool = False):
    os.makedirs(folder, exist_ok=True)
    lines = ['<?xml version="1.0" encoding="utf-8"?>',
             '<!-- Сгенерировано tools/gen_strings.py — правь там, не здесь -->',
             '<resources>']
    for k, v in S.items():
        text = v[idx]
        if latin:
            text = to_latin(text)
        is_default = os.path.basename(folder) == "values"
        if k == "app_name" and not is_default:
            continue  # название не переводится
        attrs = ' translatable="false"' if k == "app_name" else ""
        lines.append(f'    <string name="{k}"{attrs}>{esc(text)}</string>')
    for k, v in P.items():
        lines.append(f'    <plurals name="{k}">')
        for q, t in v[idx].items():
            lines.append(f'        <item quantity="{q}">{esc(to_latin(t) if latin else t)}</item>')
        lines.append('    </plurals>')
    lines.append('</resources>\n')
    with open(os.path.join(folder, "strings.xml"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


if __name__ == "__main__":
    res = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res")
    write(os.path.join(res, "values"), 0)
    write(os.path.join(res, "values-kk"), 0)
    write(os.path.join(res, "values-b+kk+Latn"), 0, latin=True)
    write(os.path.join(res, "values-ru"), 1)
    write(os.path.join(res, "values-en"), 2)
    print("strings.xml: ok")
